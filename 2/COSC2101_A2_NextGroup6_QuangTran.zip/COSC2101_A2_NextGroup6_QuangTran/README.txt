QuickManage
Assignment 2, COSC2101 SE: Process & Tools
Copyright 2013 NEXT Group (Trinh Luan s3372775, Cao Phi Hung s3372748, Nguyen Manh Hung s3372790, Dao Tien Minh s3357663, Ngo Tan Thinh s3357678)
RMIT International University Vietnam

This assignment includes software developed by the above mentioned students.

This software uses the xSwingx library file, which is open source software, written by and copyright Google Project Hosting. This file can be redistributed free of charge in unmodified binary form. The original software is available from: https://code.google.com/p/xswingx/wiki/GettingStarted

This software uses the JCalendar library package, which is open source software, written by and copyright 1999 - 2011 Kai Toedter. This file can be redistributed free of charge in unmodified binary form. The original software is available from: http://www.toedter.com/en/jcalendar/

This software uses JUnit to write unit test for the some of the classes in Model pakage. The library was developed by Java and distributed under IBM's Common Public Lisense.

This software uses Commons_IO to save files. The library is deveoped by Apache Software Foundation and under Apache Lisence.

Team contribution:

	Dao Tien Minh - team leader : 20%
	Trinh Luan : 20%
	Cao Phi Hung: 20%
	Nguyen Manh Hung: 20%
	Ngo Tan Thinh: 20%

File description:
	- Sept_A1_G6: source code of the project
	- dist : Executable jar file of the project
	- UserGuide: contains HTML and pictures to show help to user
	- SAD, SRS: Documentation
	- Library: to add more addtional features

Login info: default username and password:
	username: manager
	password: Manager1*

Acknowledgement:
NextGroup is greatful for such abundant and useful libraries developed and distributed for free from Google Project Hosting, Kai Toedter, IBM and Apache Software Foundation. 
Without open source libraries, QuickMange could not be completed as it is today.
