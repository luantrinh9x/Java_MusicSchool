package Main;

import Model.*;
import View.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {

        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {

                Data.loadAllData();

                for (Manager ma : Data.managerList) {
                    System.out.println("First name: " + ma.getFirstName());
                    System.out.println("Email: " + ma.getEmail());
                    System.out.println(ma.getStatus());
                }

                //Create the Login Form and start the program
                LoginForm login = LoginForm.getInstance();
                login.initialize();
                login.getUsernameF().setText("manager");
                login.getPasswordF().setText("Manager1*");

            }
        });
    }
}
