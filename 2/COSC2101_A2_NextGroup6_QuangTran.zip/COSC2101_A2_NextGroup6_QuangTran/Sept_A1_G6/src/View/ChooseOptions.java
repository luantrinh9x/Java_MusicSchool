package View;

import Controller.*;
import Model.*;
import javax.swing.*;

public class ChooseOptions extends JFrame {

    private static ChooseOptions unique;
    private JComboBox<String> types;
    private JButton addButton, cancelButton;
    private boolean added = false;
    private ChooseOptionsController opCon = new ChooseOptionsController();

    public ChooseOptions() {
        this.types = new JComboBox<>();
    }

    public static ChooseOptions getInstance() {
        if (unique == null) {
            unique = new ChooseOptions();
        }
        return unique;
    }

    public void initialize() {

        JLabel instruction = new JLabel("Choose a type to add");
        addButton = new JButton("Choose");
        cancelButton = new JButton("Cancel");

        // label settings
        instruction.setBounds(85, 10, 300, 20);

        // button settings
        addButton.setBounds(50, 80, 80, 30);
        cancelButton.setBounds(160, 80, 80, 30);

        // combo box settings
        types.setBounds(95, 40, 100, 30);

        if (!added) {
            if (Data.getCurrentUser() instanceof Manager) {
                types.addItem("Manager");
            }
            types.addItem("Staff");
            types.addItem("Teacher");
            types.addItem("Student");
            types.addItem("Class");
            added = true;
        }


        // add components
        add(instruction);
        add(types);
        add(addButton);
        addButton.addActionListener(opCon);

        add(cancelButton);
        cancelButton.addActionListener(opCon);
        this.addWindowListener(opCon);

        // frame settings
        setTitle("Choose Type");
        setLayout(null);
        setSize(300, 150);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);

        //Set look and feel
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            SwingUtilities.updateComponentTreeUI(this);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Can't change look and feel", "Invalid PLAF",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public JComboBox<String> getTypes() {
        return types;
    }

    public void setTypes(JComboBox<String> types) {
        this.types = types;
    }
}
