package View;

import Controller.*;
import javax.swing.*;

public class AssignmentForm extends EnrollmentForm {

    //Properties
    private static AssignmentForm uniqueAss;
    private AssignmentFormController asCon = new AssignmentFormController();
    
    public static AssignmentForm getInstanceAss() {
        if (uniqueAss == null) {
            uniqueAss = new AssignmentForm();
        }
        return uniqueAss;
    }
    
    @Override
    public void initialize(String option) {
        super.initialize("No");
        asCon.addObserver(this);

        //Settings
        enrollNote.setText("Assigned");
        enrolledList.setToolTipText("assignedList");

        //Set listeners
        close.addActionListener(asCon);
        classesList.addListSelectionListener(asCon);
        enrolledList.addListSelectionListener(asCon);

        //Set settings for the ManagerForm
        setTitle("Assignment Form");
        this.addWindowListener(asCon);

        //Set look and feel
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            SwingUtilities.updateComponentTreeUI(this);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Can't change look and feel", "Invalid PLAF",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static AssignmentForm getUniqueAss() {
        return uniqueAss;
    }
    
    public static void setUniqueAss(AssignmentForm uniqueAss) {
        AssignmentForm.uniqueAss = uniqueAss;
    }
    
    public AssignmentFormController getAsCon() {
        return asCon;
    }
    
    public void setAsCon(AssignmentFormController asCon) {
        this.asCon = asCon;
    }
}
