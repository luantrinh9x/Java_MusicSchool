package View;

import Controller.*;
import Model.*;
import View.ControlPanelFormUtilities.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.*;
import javax.imageio.*;
import javax.swing.*;
import org.jdesktop.xswingx.*;

public class ControlPanelForm extends JFrame implements Observer {

    private static ControlPanelForm unique;
    //Controllers for the form and buttons
    private ControlPanelFormController cpCon = new ControlPanelFormController();
    private DeleteButtonController deleteCon = new DeleteButtonController();
    private ActivateButtonController activateCon = new ActivateButtonController();
    private CopyClassController copyCon = new CopyClassController();
    private ReportChooseController reportChooseCon = new ReportChooseController();
    //This font will be used for all components in this class
    private Font font = new Font("Comic sans ms", Font.ROMAN_BASELINE, 13);
    //declare menu bar
    private JMenuBar menuBar = new JMenuBar();
    //declare menu
    private JMenu file = new JMenu("File");
    private JMenu help = new JMenu("Help");
    //declare menu item
    private JMenuItem exit = new JMenuItem("    Exit");
    private JMenuItem logout = new JMenuItem("    Logout");
    private JMenuItem userGuide = new JMenuItem("    User Guide");
    //One mother Panel contains all sub panels
    private JPanel mainPanel = new JPanel();
    /*There are three sub panels in Main Panel: 
     * Function panel (Location:Top)
     * Personal Info panel (Location: Left)
     * ScrollPaneInfo panel (Location: Right)
     */
    private JPanel functionPanel = new JPanel();
    private PersonalInfo personalInfo;
    private ScrollPanelInfo scrollInfo;
    //Components of functionPanel 
    private JButton addButton = new JButton("Add");
    private JButton deleteButton = new JButton("Delete");
    private JButton activateButton = new JButton("Activate");
    private JButton timeTableButton = new JButton("TimeTable");
    private JButton copyClass = new JButton("Copy Class");
    private JButton report = new JButton("Report");
    private String[] comboBoxContents;
    private JComboBox userType;
    private String identifyUser;
    private JTextField searchField = new JTextField();
    private JButton search = new JButton("Search");
    private BufferedImage myPicture;
    private JLabel picLabel;
    //Observer of this Panel
    private Data dat = new Data();

    public static ControlPanelForm getInstance() {
        if (unique == null) {
            unique = new ControlPanelForm();
        }
        return unique;
    }

    public void initialize() {
        //Set layout
        mainPanel.setLayout(null);
        mainPanel.setBackground(Color.BLACK);
        //Initialize components
        if (Data.getCurrentUser() instanceof Manager) {
            identifyUser = "Manager";
        } else {
            identifyUser = "Staff";
            report.setEnabled(false);
        }
        if (identifyUser.equalsIgnoreCase("Manager")) {
            comboBoxContents = new String[]{"Teacher", "Student", "Class", "Manager", "Staff",};
        } else if (identifyUser.equalsIgnoreCase("Staff")) {
            comboBoxContents = new String[]{"Teacher", "Student", "Class", "Staff",};
        }
        userType = new JComboBox(comboBoxContents);
        userGuide.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, ActionEvent.ALT_MASK));
        makeFunctionPanel();
        personalInfo = PersonalInfo.getInstance();
        personalInfo.initialize();
        scrollInfo = ScrollPanelInfo.getInstance();
        scrollInfo.initialize(deleteCon, activateCon, copyCon);

        //Add components
        file.add(logout);
        file.add(exit);
        help.add(userGuide);
        menuBar.add(file);
        menuBar.add(help);
        add(menuBar, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);
        mainPanel.add(functionPanel);
        mainPanel.add(personalInfo);
        mainPanel.add(scrollInfo);
        //Set settings for the ControlPanelForm
        setTitle("Quick Manage");
        setSize(999, 710);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        //Set listerners and Observer
        setControllers();
        dat.addObserver(this);
        //Set UI
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            SwingUtilities.updateComponentTreeUI(this);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Can't change look and feel", "Invalid PLAF",
                    JOptionPane.ERROR_MESSAGE);
        }

    }

    public void setControllers() {
        addButton.addActionListener(cpCon);
        userType.addActionListener(cpCon);
        timeTableButton.addActionListener(cpCon);
        exit.addActionListener(cpCon);
        logout.addActionListener(cpCon);
        userGuide.addActionListener(cpCon);
        deleteButton.addActionListener(deleteCon);
        activateButton.addActionListener(activateCon);
        copyClass.addActionListener(copyCon);
        report.addActionListener(reportChooseCon);
        search.addActionListener(cpCon);
    }

    public void makeFunctionPanel() {
        //Set layout and background color for function panel
        functionPanel.setLayout(null);
        functionPanel.setBackground(new Color(213, 227, 255)); // Set color for top layout
        //Initialize
        DefaultListCellRenderer dlcr = new DefaultListCellRenderer();
        dlcr.setHorizontalAlignment(DefaultListCellRenderer.CENTER);
        userType.setRenderer(dlcr);//make the text appear center
        PromptSupport.setPrompt("Search...", searchField);//search hint
        URL url = ControlPanelForm.class.getResource("/Images/CP.png");//initialize image
        try {
            myPicture = ImageIO.read(url);
        } catch (IOException ex) {
            Logger.getLogger(ControlPanelForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        picLabel = new JLabel(new ImageIcon(myPicture));
        picLabel.setOpaque(false);
        //Set location of buttons panel components
        functionPanel.setBounds(0, 0, 993, 75);
        addButton.setBounds(5, 5, 120, 30);
        deleteButton.setBounds(130, 5, 120, 30);
        activateButton.setBounds(255, 5, 120, 30);
        timeTableButton.setBounds(380, 5, 120, 30);
        copyClass.setBounds(505, 5, 120, 30);
        report.setBounds(630, 5, 120, 30);
        userType.setBounds(335, 40, 120, 30);
        searchField.setBounds(465, 40, 355, 30);
        search.setBounds(828, 40, 90, 30);
        picLabel.setBounds(900, 10, 100, 60);
        //set font for all components of both panels
        addButton.setFont(font);
        deleteButton.setFont(font);
        activateButton.setFont(font);
        timeTableButton.setFont(font);
        userType.setFont(font);
        searchField.setFont(font);
        search.setFont(font);
        copyClass.setFont(font);
        report.setFont(font);

        //Add components to function panel
        functionPanel.add(addButton);
        functionPanel.add(deleteButton);
        functionPanel.add(activateButton);
        functionPanel.add(timeTableButton);
        functionPanel.add(copyClass);
        functionPanel.add(report);
        functionPanel.add(userType);
        functionPanel.add(searchField);
        functionPanel.add(search);
        functionPanel.add(picLabel);
    }

    @Override
    public void update(Observable o, Object arg) {
    }

    public String getSearch() {
        return userType.getSelectedItem().toString() + "." + this.searchField.getText();
    }

    public static void setUnique(ControlPanelForm unique) {
        ControlPanelForm.unique = unique;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public JButton getActivateButton() {
        return activateButton;
    }

    public JButton getCopyClass() {
        return copyClass;
    }

    public JButton getReport() {
        return report;
    }
    
    public JComboBox getUserType() {
        return userType;
    }
}
