package Controller;

import Model.*;
import View.*;
import View.ControlPanelFormUtilities.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

public class ControlPanelFormController implements ActionListener {

    private static ArrayList<String> types = new ArrayList<>();
    private static ArrayList<String> ids = new ArrayList<>();
    private static ArrayList<String> names = new ArrayList<>();
    private static ArrayList<String> infoOne = new ArrayList<>();
    private static ArrayList<String> infoTwo = new ArrayList<>();
    private static ArrayList<String> dates = new ArrayList<>();
    private static ArrayList<Boolean> status = new ArrayList<>();

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton but = (JButton) e.getSource();

            if (but.getText().equals("Add")) {
                ChooseOptions add = ChooseOptions.getInstance();
                add.initialize();
                ControlPanelForm.getInstance().setEnabled(false);
            } else if (but.getText().equals("TimeTable")) {
                AllTimeTable.setUnique(null);
                AllTimeTable alltime = AllTimeTable.getInstance();
                alltime.initialize();
                ControlPanelForm.getInstance().setEnabled(false);
            } else if (but.getText().equals("Search")) {
                types = new ArrayList<>();
                ids = new ArrayList<>();
                names = new ArrayList<>();
                infoOne = new ArrayList<>();
                infoTwo = new ArrayList<>();
                dates = new ArrayList<>();
                status = new ArrayList<>();
                String[] input = ControlPanelForm.getInstance().getSearch().split("\\.");
                if (input.length == 2) {
                    if (input[0].equals("Manager")) {
                        rightPanelLoadManager(input[1]);
                    } else if (input[0].equals("Staff")) {
                        rightPanelLoadStaff(input[1]);
                    } else if (input[0].equals("Student")) {
                        rightPanelLoadStudent(input[1]);
                    } else if (input[0].equals("Teacher")) {
                        rightPanelLoadTeacher(input[1]);
                    } else if (input[0].equals("Class")) {
                        rightPanelLoadClass(input[1]);
                    }
                }
            }
        } else if (e.getSource() instanceof JComboBox) {
            JComboBox cb = (JComboBox) e.getSource();

            if (cb.getSelectedItem().toString().equals("Manager")) {
                ControlPanelForm.getInstance().getDeleteButton().setEnabled(true);
                ControlPanelForm.getInstance().getActivateButton().setEnabled(true);
                ControlPanelForm.getInstance().getCopyClass().setEnabled(false);
                rightPanelLoadManager();

            } else if (cb.getSelectedItem().toString().equals("Staff")) {
                ControlPanelForm.getInstance().getDeleteButton().setEnabled(true);
                ControlPanelForm.getInstance().getActivateButton().setEnabled(true);
                ControlPanelForm.getInstance().getCopyClass().setEnabled(false);
                rightPanelLoadStaff();

            } else if (cb.getSelectedItem().toString().equals("Student")) {
                ControlPanelForm.getInstance().getDeleteButton().setEnabled(true);
                ControlPanelForm.getInstance().getActivateButton().setEnabled(true);
                ControlPanelForm.getInstance().getCopyClass().setEnabled(false);
                rightPanelLoadStudent();

            } else if (cb.getSelectedItem().toString().equals("Teacher")) {
                ControlPanelForm.getInstance().getDeleteButton().setEnabled(true);
                ControlPanelForm.getInstance().getActivateButton().setEnabled(true);
                ControlPanelForm.getInstance().getCopyClass().setEnabled(false);
                rightPanelLoadTeacher();

            } else if (cb.getSelectedItem().toString().equals("Class")) {
                ControlPanelForm.getInstance().getDeleteButton().setEnabled(true);
                ControlPanelForm.getInstance().getActivateButton().setEnabled(false);
                ControlPanelForm.getInstance().getCopyClass().setEnabled(true);
                rightPanelLoadClass();

            }
        } else if (e.getSource() instanceof JMenuItem) {
            JMenuItem me = (JMenuItem) e.getSource();
            if (me.getText().equalsIgnoreCase("    User Guide")) {
                Desktop d = Desktop.getDesktop();
                try {
                    d.open(new File("UserGuide\\userguide.html"));
                } catch (IOException ex) {
                    ex.getMessage();
                }
            } else if (me.getText().equalsIgnoreCase("    Exit")) {
                System.exit(0);
            } else if (me.getText().equalsIgnoreCase("    Logout")) {
                ControlPanelForm.getInstance().dispose();
                LoginForm.getInstance().setVisible(true);
            }
        }
   
    }

    public static void rightPanelLoadManager() {
        types = new ArrayList<>();
        ids = new ArrayList<>();
        names = new ArrayList<>();
        infoOne = new ArrayList<>();
        infoTwo = new ArrayList<>();
        dates = new ArrayList<>();
        status = new ArrayList<>();
        for (int i = 0; i < Data.managerList.size(); i++) {
            String name = Data.managerList.get(i).getFirstName() + " " + Data.managerList.get(i).getLastName();
            ids.add(Data.managerList.get(i).getID());
            names.add(name);
            types.add(Data.managerList.get(i).getUserType());
            infoOne.add("");
            infoTwo.add(Data.managerList.get(i).getEmail());
            dates.add(Data.managerList.get(i).getCurrentdate());
            boolean temp;
            if (Data.managerList.get(i).getStatus().equalsIgnoreCase("Activate")) {
                temp = true;
            } else {
                temp = false;
            }
            status.add(temp);
        }

        ScrollPanelInfo.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);
    }

    public static void rightPanelLoadTeacher() {
        types = new ArrayList<>();
        ids = new ArrayList<>();
        names = new ArrayList<>();
        infoOne = new ArrayList<>();
        infoTwo = new ArrayList<>();
        dates = new ArrayList<>();
        status = new ArrayList<>();
        for (int i = 0; i < Data.teacherList.size(); i++) {
            String name = Data.teacherList.get(i).getFirstName() + " " + Data.teacherList.get(i).getLastName();
            ids.add(Data.teacherList.get(i).getID());
            names.add(name);
            types.add(Data.teacherList.get(i).getUserType());
            infoOne.add("");
            infoTwo.add(Data.teacherList.get(i).getEmail());
            dates.add(Data.teacherList.get(i).getCurrentdate());
            boolean temp;
            if (Data.teacherList.get(i).getStatus().equalsIgnoreCase("Activate")) {
                temp = true;
            } else {
                temp = false;
            }
            status.add(temp);
        }
        ScrollPanelInfo.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);
    }

    public static void rightPanelLoadStaff() {
        types = new ArrayList<>();
        ids = new ArrayList<>();
        names = new ArrayList<>();
        infoOne = new ArrayList<>();
        infoTwo = new ArrayList<>();
        dates = new ArrayList<>();
        status = new ArrayList<>();
        for (int i = 0; i < Data.staffList.size(); i++) {
            String name = Data.staffList.get(i).getFirstName() + " " + Data.staffList.get(i).getLastName();
            ids.add(Data.staffList.get(i).getID());
            names.add(name);
            types.add(Data.staffList.get(i).getUserType());
            infoOne.add("");
            infoTwo.add(Data.staffList.get(i).getEmail());
            dates.add(Data.staffList.get(i).getCurrentdate());
            boolean temp;
            if (Data.staffList.get(i).getStatus().equalsIgnoreCase("Activate")) {
                temp = true;
            } else {
                temp = false;
            }
            status.add(temp);
        }
        ScrollPanelInfo.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);
    }

    public static void rightPanelLoadStudent() {
        types = new ArrayList<>();
        ids = new ArrayList<>();
        names = new ArrayList<>();
        infoOne = new ArrayList<>();
        infoTwo = new ArrayList<>();
        dates = new ArrayList<>();
        status = new ArrayList<>();
        for (int i = 0; i < Data.studentList.size(); i++) {
            String name = Data.studentList.get(i).getFirstName() + " " + Data.studentList.get(i).getLastName();
            ids.add(Data.studentList.get(i).getID());
            names.add(name);
            types.add(Data.studentList.get(i).getUserType());
            infoOne.add("");
            infoTwo.add(Data.studentList.get(i).getEmail());
            dates.add(Data.studentList.get(i).getCurrentdate());
            boolean temp;
            if (Data.studentList.get(i).getStatus().equalsIgnoreCase("Activate")) {
                temp = true;
            } else {
                temp = false;
            }
            status.add(temp);
        }
        ScrollPanelInfo.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);
    }

    public static void rightPanelLoadClass() {
        types = new ArrayList<>();
        ids = new ArrayList<>();
        names = new ArrayList<>();
        infoOne = new ArrayList<>();
        infoTwo = new ArrayList<>();
        dates = new ArrayList<>();
        status = new ArrayList<>();
        for (int i = 0; i < Data.classList.size(); i++) {
            ids.add(Data.classList.get(i).getId());
            names.add(Data.classList.get(i).getClassName());
            types.add(Data.classList.get(i).getClassLabel());
            infoOne.add(Data.classList.get(i).getClassCode());
            infoTwo.add(Data.classList.get(i).getClassType());
            dates.add(Data.classList.get(i).getCurrentDate());
            status.add(true);
        }
        ScrollPanelInfo.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);
    }

    public static void rightPanelLoadManager(String search) {
        //Change to 0 Tomorrow
        for (int i = 0; i < Data.managerList.size(); i++) {
            String name = Data.managerList.get(i).getFirstName() + " " + Data.managerList.get(i).getLastName();
            String[] day = Data.managerList.get(i).getCurrentdate().split("\\,");
            String[] month = day[1].split("\\s");
            if (name.contains(search) || day[0].contains(search)
                    || search.contains(month[0]) || month[1].contains(search)
                    || Data.managerList.get(i).getEmail().toString().contains(search)) {
                ids.add(Data.managerList.get(i).getID());
                names.add(name);
                types.add(Data.managerList.get(i).getUserType());
                infoOne.add("");
                infoTwo.add(Data.managerList.get(i).getEmail());
                dates.add(Data.managerList.get(i).getCurrentdate());
                boolean temp;
                if (Data.managerList.get(i).getStatus().equalsIgnoreCase("Activate")) {
                    temp = true;
                } else {
                    temp = false;
                }
                status.add(temp);
            }
        }
        ScrollPanelInfo.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);
    }

    public static void rightPanelLoadTeacher(String search) {
        for (int i = 0; i < Data.teacherList.size(); i++) {
            String name = Data.teacherList.get(i).getFirstName() + " " + Data.teacherList.get(i).getLastName();
            String[] day = Data.teacherList.get(i).getCurrentdate().split("\\,");
            String[] month = day[1].split("\\s");
            if (name.contains(search) || day[0].contains(search)
                    || search.contains(month[0]) || month[1].contains(search)
                    || Data.teacherList.get(i).getEmail().toString().contains(search)) {
                ids.add(Data.teacherList.get(i).getID());
                names.add(name);
                types.add(Data.teacherList.get(i).getUserType());
                infoOne.add("");
                infoTwo.add(Data.teacherList.get(i).getEmail());
                dates.add(Data.teacherList.get(i).getCurrentdate());
                boolean temp;
                if (Data.teacherList.get(i).getStatus().equalsIgnoreCase("Activate")) {
                    temp = true;
                } else {
                    temp = false;
                }
                status.add(temp);
            }
        }
        ScrollPanelInfo.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);
    }

    public static void rightPanelLoadStaff(String search) {
        for (int i = 0; i < Data.staffList.size(); i++) {
            String name = Data.staffList.get(i).getFirstName() + " " + Data.staffList.get(i).getLastName();
            String[] day = Data.staffList.get(i).getCurrentdate().split("\\,");
            String[] month = day[1].split("\\s");
            if (name.contains(search) || day[0].contains(search)
                    || search.contains(month[0]) || month[1].contains(search)
                    || Data.staffList.get(i).getEmail().toString().contains(search)) {
                ids.add(Data.staffList.get(i).getID());
                names.add(name);
                types.add(Data.staffList.get(i).getUserType());
                infoOne.add("");
                infoTwo.add(Data.staffList.get(i).getEmail());
                dates.add(Data.staffList.get(i).getCurrentdate());
                boolean temp;
                if (Data.staffList.get(i).getStatus().equalsIgnoreCase("Activate")) {
                    temp = true;
                } else {
                    temp = false;
                }
                status.add(temp);
            }
        }
        ScrollPanelInfo.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);
    }

    public static void rightPanelLoadStudent(String search) {
        for (int i = 0; i < Data.studentList.size(); i++) {
            String name = Data.studentList.get(i).getFirstName() + " " + Data.studentList.get(i).getLastName();
            String[] day = Data.studentList.get(i).getCurrentdate().split("\\,");
            String[] month = day[1].split("\\s");
            if (name.contains(search) || day[0].contains(search)
                    || search.contains(month[0]) || month[1].contains(search)
                    || Data.studentList.get(i).getEmail().toString().contains(search)) {
                ids.add(Data.studentList.get(i).getID());
                names.add(name);
                types.add(Data.studentList.get(i).getUserType());
                infoOne.add("");
                infoTwo.add(Data.studentList.get(i).getEmail());
                dates.add(Data.studentList.get(i).getCurrentdate());
                boolean temp;
                if (Data.studentList.get(i).getStatus().equalsIgnoreCase("Activate")) {
                    temp = true;
                } else {
                    temp = false;
                }
                status.add(temp);
            }
        }
        ScrollPanelInfo.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);
    }

    public static void rightPanelLoadClass(String search) {
        for (int i = 0; i < Data.classList.size(); i++) {
            String[] day = Data.classList.get(i).getCurrentDate().split("\\,");
            String[] month = day[1].split("\\s");
            if (Data.classList.get(i).getClassName().contains(search) || Data.classList.get(i).getClassCode().contains(search)
                    || day[0].contains(search) || search.contains(month[0]) || month[1].contains(search)
                    || Data.classList.get(i).getClassType().contains(search)) {
                ids.add(Data.classList.get(i).getId());
                names.add(Data.classList.get(i).getClassName());
                types.add(Data.classList.get(i).getClassLabel());
                infoOne.add(Data.classList.get(i).getClassCode());
                infoTwo.add(Data.classList.get(i).getClassType());
                dates.add(Data.classList.get(i).getCurrentDate());
                status.add(true);
            }
        }
        ScrollPanelInfo.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);
    }
}
