package Controller;

import View.*;
import java.awt.event.*;
import javax.swing.*;

public class ChooseOptionsController implements ActionListener, WindowListener {

    @Override
    public void actionPerformed(ActionEvent ae) {
        JButton but = (JButton) ae.getSource();
        switch (but.getText()) {
            case "Choose":
                ChooseOptions options = ChooseOptions.getInstance();

                if (options.getTypes().getSelectedItem().equals("Class")) {
                    ClassForm.setUnique(null);
                    ClassForm classForm = ClassForm.getInstance();
                    classForm.initialize();
                    classForm.setOption("add");
                } else if (options.getTypes().getSelectedItem().equals("Manager")) {
                    ManagerForm.setUnique(null);
                    ManagerForm manager = ManagerForm.getInstance();
                    manager.managerInitialize();
                    manager.setOption("add");
                } else if (options.getTypes().getSelectedItem().equals("Staff")) {
                    StaffForm.setUnique(null);
                    StaffForm staff = StaffForm.getInstance();
                    staff.staffInitialize();
                    staff.setOption("add");
                } else if (options.getTypes().getSelectedItem().equals("Teacher")) {
                    TeacherForm.setUnique(null);
                    TeacherForm teacher = TeacherForm.getInstance();
                    teacher.teacherInitialize();
                    teacher.setOption("add");
                    teacher.getCancel().setBounds(270, 560, 80, 25);
                    teacher.getAssignButton().setVisible(true);
                } else if (options.getTypes().getSelectedItem().equals("Student")) {
                    StudentForm.setUnique(null);
                    StudentForm student = StudentForm.getInstance();
                    student.studentInitialize();
                    student.setOption("add");
                    student.getCancel().setBounds(400, 450, 100, 25);
                    student.getEnrollButton().setVisible(true);
                    
                }
                options.dispose();
                break;
            case "Cancel":
                ChooseOptions.getInstance().setVisible(false);
                ChooseOptions.getInstance().dispose();
                ControlPanelForm.getInstance().setEnabled(true);
                ControlPanelForm.getInstance().setVisible(true);
                break;
        }
    }

    @Override
    public void windowOpened(WindowEvent e) {
    }

    @Override
    public void windowClosing(WindowEvent e) {
        ControlPanelForm.getInstance().setEnabled(true);
        ControlPanelForm.getInstance().setVisible(true);
    }

    @Override
    public void windowClosed(WindowEvent e) {
    }

    @Override
    public void windowIconified(WindowEvent e) {
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
    }

    @Override
    public void windowActivated(WindowEvent e) {
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
    }
}
