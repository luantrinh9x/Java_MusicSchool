package Controller;

import Model.*;
import java.awt.event.*;

public class CopyClassController implements ActionListener {

    private String id;

    @Override
    public void actionPerformed(ActionEvent ae) {
        System.out.println(id);
        if (id != null) {
            Data data = new Data();
            data.copyClasses(id);
        }
    }

    public void removeOldIDs() {
        this.id = new String();
    }

    public void setId(String id) {
        this.id = id;
    }
}
