package Controller;

import Model.Data;
import Model.Invoice;
import View.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class ReportChooseController implements ActionListener, WindowListener {

    @Override
    public void actionPerformed(ActionEvent ae) {


        JButton but = (JButton) ae.getSource();
        if (ae.getSource() instanceof JButton) {
            if (but.getText().equalsIgnoreCase("Report")) {
                ReportChooseForm.setUnique(null);
                ReportChooseForm rcf = ReportChooseForm.getInstance();
                rcf.initialize();
            } else if (but.getText().equalsIgnoreCase("Choose")) {
                String month = (String) ReportChooseForm.getInstance().getMonthCombo().getSelectedItem();
                String year = (String) ReportChooseForm.getInstance().getYearCombo().getSelectedItem();
                ReportForm.setUnique(null);
                ReportForm rf = ReportForm.getInstance();
                rf.initialize(month,year, Data.studentList);
                ReportChooseForm report = ReportChooseForm.getInstance();
                report.dispose();
            } else if (but.getText().equalsIgnoreCase("Cancel")) {
                ReportChooseForm report = ReportChooseForm.getInstance();
                report.dispose();
                ControlPanelForm.getInstance().setEnabled(true);
                ControlPanelForm.getInstance().setVisible(true);
            }
        }
    }

    @Override
    public void windowOpened(WindowEvent we) {
    }

    @Override
    public void windowClosing(WindowEvent we) {
        ControlPanelForm.getInstance().setEnabled(true);
        ControlPanelForm.getInstance().setVisible(true);
    }

    @Override
    public void windowClosed(WindowEvent we) {
    }

    @Override
    public void windowIconified(WindowEvent we) {
    }

    @Override
    public void windowDeiconified(WindowEvent we) {
    }

    @Override
    public void windowActivated(WindowEvent we) {
    }

    @Override
    public void windowDeactivated(WindowEvent we) {
    }
}
