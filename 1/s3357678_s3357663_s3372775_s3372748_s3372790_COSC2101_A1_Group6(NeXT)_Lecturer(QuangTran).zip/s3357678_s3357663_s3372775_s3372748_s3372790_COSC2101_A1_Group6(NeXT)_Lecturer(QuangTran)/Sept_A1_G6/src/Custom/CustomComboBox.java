/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Custom;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.plaf.basic.BasicComboBoxUI;

/**
 *
 * @author minh
 */
public class CustomComboBox {
    
    /* This method get rid of the arrow on the right of a combo box 
     * Code modified from:
     * http://stackoverflow.com/questions/822432/how-to-make-jcombobox-look-like-a-jtextfield 
     * This combo box is used in AddClassForm
     */
    public static JComboBox createCustomComboBox(JComboBox<String> cb){
        cb.setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton(){
                return new JButton(){
                    @Override
                    public int getWidth(){
                        return 0;
                    }
                };
            }
        });
        return cb;
    }
}
