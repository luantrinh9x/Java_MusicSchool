package Controller;

import Model.*;
import View.*;
import java.awt.event.*;
import javax.swing.*;

public class ManagerFormController implements ActionListener {

    private JFileChooser fc;
    private ManagerForm mf;
    private boolean[] checkResults = new boolean[8];
    private boolean finalResult = true;

    public ManagerFormController(ManagerForm mf) {
        this.mf = mf;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        JButton but = (JButton) ae.getSource();

        if (but.getText().equals("Add")) {
            // checkResult data from manaager form
            DataValidation dv = new DataValidation();
            checkResults[0] = dv.checkName(mf.getFirstnameR().getText());
            checkResults[1] = dv.checkName(mf.getLastnameR().getText());
            checkResults[2] = dv.checkHomePhoneNumber(mf.getHomeNumR().getText());
            checkResults[3] = dv.checkCellPhoneNumber(mf.getPhoneNumR().getText());
            checkResults[4] = dv.checkEmail(mf.getEmailR().getText());
            checkResults[5] = dv.checkUserName(mf.getUserName().getText());
            checkResults[6] = dv.checkPassword(mf.getTypingPassword().getPassword());
            checkResults[7] = dv.checkRetypePassword(mf.getTypingPassword().getPassword(), mf.getRetypePassword().getPassword());

            for (int i = 0; i < checkResults.length; i++) {
                if(checkResults[i]==false){
                    finalResult = false;
                    System.out.println(i);
                }
            }
            // check if all data input has the right format
            if (finalResult) {
                // add manager into system
                Data data = new Data(ManagerForm.getInstance());
                data.saveManagerData(Data.managerList);
                ControlPanelForm.getInstance().initialize();
                ManagerForm.getInstance().dispose();
                ControlPanelForm.getInstance().setEnabled(true);
                ControlPanelForm.getInstance().setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "Invalid inputs");
                finalResult = true; // return finalResult to initial state
            }
                


        } else if (but.getText().equals("Cancel")) {
            ManagerForm manager = ManagerForm.getInstance();
            manager.dispose();
            ControlPanelForm cpf = ControlPanelForm.getInstance();
            cpf.setEnabled(true);
            cpf.setVisible(true);
        } else if (but.getText().equals("Browse")) {
            // Set up the file chooser

            if (fc == null) {
                fc = new JFileChooser();

                //Add a custom file filter and disable the default
                //(Accept All) file filter.
                fc.addChoosableFileFilter(new ImageFilter());
                fc.setAcceptAllFileFilterUsed(false);

                //Add custom icons for file types.
                fc.setFileView(new ImageFileView());

                //Add the preview pane.
                fc.setAccessory(new ImagePreview(fc));
            }

            //Show it.
            int returnVal = fc.showDialog(fc,
                    "Attach");

            //Process the results.
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                System.out.println(fc.getSelectedFile().getPath());
                ManagerForm manager = ManagerForm.getInstance();
                manager.setImagePath(fc.getSelectedFile().getPath());
                manager.managerInitialize();
            }

            //Reset the file chooser for the next time it's shown.
            fc.setSelectedFile(null);
        }

    }
}
