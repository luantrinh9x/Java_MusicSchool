/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.StudentListItem;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JList;

/**
 *
 * @author minh
 */
public class StudentListController implements MouseListener {

    @Override
    public void mouseClicked(MouseEvent e) {
        JList list = (JList) e.getSource();
        int index = list.locationToIndex(e.getPoint());
        StudentListItem ci = (StudentListItem) list.getModel().getElementAt(index);
        System.out.println(ci.toString());
        ci.setSelected(!ci.isSelected());
        list.repaint(list.getCellBounds(index, index));
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
