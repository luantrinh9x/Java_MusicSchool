/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Data;
import View.ControlPanelForm;
import View.EnrollmentForm;
import View.StudentForm;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author Thinh
 */
public class EnrollmentFormController extends Observable implements ActionListener, ListSelectionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
        EnrollmentForm en = EnrollmentForm.getInstance();
        en.dispose();
        ControlPanelForm control = ControlPanelForm.getInstance();
        control.setVisible(true);
        StudentForm stu = StudentForm.getInstance();
        stu.setEnabled(true);
        stu.setVisible(true);


    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        JList li = (JList) e.getSource();
        String item = (String) li.getSelectedValue();
//        Student tempstu = Data.getCurrentStudentEnroll();
        EnrollmentForm en = EnrollmentForm.getInstance();

        en.getTimeTable().getTimeModel().resetChosenClass();
        en.getTimeTable().getTimeModel().change();
        
        //Loop through all Data classes
        for (int i = 0; i < Data.classList.size(); i++) {

            //Check each Data classes to find the right type
            if (Data.classList.get(i).getClassType().equals(item)) {

                boolean exist = false;
                //Check for each class in Student Form
                for (int k = 0; k < StudentForm.getInstance().getClasses().size(); k++) {

                    if (StudentForm.getInstance().getClasses().get(k).getId().equals(Data.classList.get(i).getId())) {
                        exist = true;
                    }
                }

                //If doesnt exist then it appears on the timetable
                if (!exist) {
                    for (int j = 0; j < Data.classList.get(i).getDays().length; j++) {
                        String from = Data.classList.get(i).getFroms()[j];
                        String tos = Data.classList.get(i).getTos()[j];

                        if (from.length() == 4) {
                            from = "0" + from;
                        }

                        if (tos.length() == 4) {
                            tos = "0" + tos;
                        }

                        en.getTimeTable().getTimeController().onCreateClass(Data.classList.get(i).getId(),
                                Data.classList.get(i).getDays()[j],
                                from, tos,
                                Data.classList.get(i).getClassName(), Data.classList.get(i).getId(), Data.classList.get(i).getClassCode(),
                                Data.classList.get(i).getRooms()[j], "");
                    }
                }



            }
        }
        en.getTimeTable().setPanelListener();


    }

    public void setModify() {
        setChanged();
        notifyObservers();
    }
}