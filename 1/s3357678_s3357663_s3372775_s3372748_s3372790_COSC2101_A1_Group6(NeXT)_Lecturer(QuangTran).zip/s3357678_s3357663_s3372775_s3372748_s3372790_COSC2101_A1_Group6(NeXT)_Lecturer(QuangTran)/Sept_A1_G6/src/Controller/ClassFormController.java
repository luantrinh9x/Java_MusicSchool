package Controller;

import Model.Data;
import Model.DataValidation;
import View.ClassForm;
import View.ControlPanelForm;
import java.awt.event.*;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class ClassFormController implements ActionListener {

    private ClassForm cf;
    private boolean checkTimeResult;

    public ClassFormController(ClassForm cf) {
        this.cf = cf;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() instanceof JButton) {
            JButton but = (JButton) ae.getSource();
            if (but.getText().equals("Done")) {

                DataValidation dv = new DataValidation();

                checkTimeResult = dv.checkClassTime(cf.getMonStartTime().getSelectedItem().toString(), cf.getMonStartTime().getSelectedItem().toString());

                if (checkTimeResult) {
                    Data data = new Data(ClassForm.getInstance());
                    data.saveClassData(Data.classList);
                    ControlPanelForm.getInstance().initialize();
                    ClassForm.getInstance().dispose();
                    ControlPanelForm.getInstance().setEnabled(true);
                    ControlPanelForm.getInstance().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid inputs");
                    checkTimeResult = true; // return finalResult to initial state
                }


            } else if (but.getText().equals("Cancel")) {
                ClassForm classForm = ClassForm.getInstance();
                classForm.dispose();
                ControlPanelForm cpf = ControlPanelForm.getInstance();
                cpf.setEnabled(true);
                cpf.setVisible(true);
            }

        }

    }
}
