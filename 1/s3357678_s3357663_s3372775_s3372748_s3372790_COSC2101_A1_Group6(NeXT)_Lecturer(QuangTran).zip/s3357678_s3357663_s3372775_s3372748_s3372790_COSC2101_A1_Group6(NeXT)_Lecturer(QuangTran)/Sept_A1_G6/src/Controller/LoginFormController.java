package Controller;

import Model.Data;
import View.*;
import View.ControlPanelFormUtilities.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class LoginFormController implements MouseListener, ActionListener, KeyListener {

    @Override
    public void mouseClicked(MouseEvent e) {
        JButton but = (JButton) e.getSource();
        if (but.getText().equals("Log in")) {
            getLogin();
        }
        if (but.getText().equals("Exit")) {
            System.exit(0);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
//        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void mouseReleased(MouseEvent e) {
//        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void mouseEntered(MouseEvent e) {
//        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void mouseExited(MouseEvent e) {
//        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JMenuItem menuitem = (JMenuItem) e.getSource();
        if (menuitem.getText().equals("      Close")) {
            System.exit(0);
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
//        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void keyPressed(KeyEvent e) {
//        throw new UnsupportedOperationException("Not supported yet.");
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            getLogin();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
//        throw new UnsupportedOperationException("Not supported yet.");
    }

    private void getLogin() {
        String user = LoginForm.getInstance().getUsrnameF().getText();
        char[] passInChar;
        passInChar = LoginForm.getInstance().getPasswordF().getPassword();
        boolean connected = false;

        for (int i = 0; i < Data.managerList.size(); i++) {
            if (Data.managerList.get(i).getUsername().equals(user)
                    && Arrays.equals(Data.managerList.get(i).getTypingPassword(), passInChar)) {
                Data.setCurrentUser(Data.managerList.get(i));
                connected = true;
                break;
            }
        }

        for (int i = 0; i < Data.staffList.size(); i++) {
            if (Data.staffList.get(i).getUsername().equals(user)
                    && Arrays.equals(Data.staffList.get(i).getTypingPassword(), passInChar)) {
                Data.setCurrentUser(Data.staffList.get(i));
                connected = true;
                break;
            }
        }

        if (connected) {
            System.out.println("Logged in");
            LoginForm.getInstance().dispose();
            ControlPanelForm.getInstance().initialize();

            String url = "C:\\Users\\Naga\\Desktop\\Near.png";
            LeftPanel.getInstance().setAllPeopleLabels("s3372790", "26/ 02/ 1993", "Viking", "KinSlayer",
                    "Male", "0995277656", "robbinhoodhungdark@gmail.com", "Live in the back yard", "GOD",
                    "Manager", url);

//            LeftPanel.getInstance().setAllClassLabels("s3372790", "COSC2171", "HOBO", "Nature Attendance", "Fiend",
//                    "$4000", "26/02/1993", "18/03/1993", "9AM", "6AM", "1.1.03", url);
//            LeftPanel.getInstance().setAllPeopleLabels("s3372790", "26/ 02/ 1993", "Viking", "KinSlayer",
//                    "Male", "0995277656", "robbinhoodhungdark@gmail.com", "Live in the back yard", "GOD", "Student", url);
//            LeftPanel.getInstance().setAllPeopleLabelsEmpty();
//            LeftPanel.getInstance().setAllClassLabelsEmpty();
//            
//            String[] types = {"Student", "Teacher", "Class", "Manager", "Staff", "Student", "Manager", "Class"};
//            String[] ids = {"s3372790", "T3372791", "C3372792", "M3372793", "S3372794", "s3372795", "M3372796", "T3372797"};
//            String[] names = {"Kelly", "Naga", "How to kill the stupid team leader", "Mighty Jax", "Jack Sparrow", "Rachel Morgan", "Myrnin", "Butterflies Slayer"};
//            String[] infoOne = {"Piano", "Kin Slayer, Killer, Reaper", "COSC2171", "", "", "Hip hop", "", "COSC4564"};
//            String[] infoTwo = {"lovely@gmail.com", "vomit@gmail.com", "VIP only", "pinkyDoll@gmail.com", "Labor@gmail.com",
//                "Labor@gmail.com", "Labor@gmail.com", "HOBO"};
//            String[] dates = {"13/13/2012", "13/13/2012", "13/13/2012", "13/13/2012", "13/13/2012", "13/13/2012",
//                "13/13/2012", "13/13/2012"};
//            boolean[] status = {true, true, false, false, true, true, false, false};
//            
//            RightPanel.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);
//            types = new String[1];
//            ids = new String[1];
//            names = new String[1];
//            infoOne = new String[1];
//            infoTwo = new String[1];
//            dates = new String[1];
//            status = new boolean[1];
//            types[0] = "Student";
//            ids[0] = "s3372790";
//            names[0] = "Darksiders";
//            infoOne[0] = "Organ";
//            infoTwo[0] = "Legendary Left Arm";
//            dates[0] = "26/02/1993";
//            status[0] = true;
//            RightPanel.getInstance().addStuffToScrollPanel(types, ids, names, infoOne, infoTwo, dates, status);

        } else {
            JOptionPane.showMessageDialog(null, "Wrong username or password");
        }
    }
}
