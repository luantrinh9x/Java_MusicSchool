/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Data;
import View.AllTimeTable;
import View.ControlPanelForm;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author Thinh
 */
public class AllTimeTableController extends Observable implements ActionListener, ListSelectionListener {

    private Data dat = new Data();
    private JList listStudent = new JList();
    private JList listTeacher = new JList();

    @Override
    public void actionPerformed(ActionEvent e) {
//        throw new UnsupportedOperationException("Not supported yet.");
        if (e.getSource() instanceof JButton) {
            JButton but = (JButton) e.getSource();
            if (but.getText().equals("Close")) {
                AllTimeTable.getInstance().dispose();
                ControlPanelForm.getInstance().setEnabled(true);
                ControlPanelForm.getInstance().setVisible(true);
            }
        }
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
//        throw new UnsupportedOperationException("Not supported yet.");
        
        JList li = (JList) e.getSource();
        String item = (String) li.getSelectedValue();
        ArrayList<String> toStu = new ArrayList<>();
        ArrayList<String> toTea = new ArrayList<>();

        for (int i = 0; i < Data.teacherList.size(); i++) {

            for (int j = 0; j < Data.teacherList.get(i).getClasses().length; i++) {
                if(Data.teacherList.get(i).getClasses()[i].equals(item)){
                    String tempName = Data.teacherList.get(i).getFirstName() + Data.teacherList.get(i).getLastName();
                    toTea.add(tempName);
                }
            }
        }

        listTeacher.setListData(toTea.toArray());
        setModify();
    }

    public Data getDat() {
        return dat;
    }

    public JList getListStudent() {
        return listStudent;
    }

    public void setListStudent(JList listStudent) {
        this.listStudent = listStudent;
    }

    public JList getListTeacher() {
        return listTeacher;
    }

    public void setListTeacher(JList listTeacher) {
        this.listTeacher = listTeacher;
    }
    
    public void setModify(){
        setChanged();
        notifyObservers();
    }
}
