package Controller;

import Model.Data;
import Model.DataValidation;
import View.*;
import java.awt.event.*;
import javax.swing.*;

public class TeacherFormController implements ActionListener {

    private JFileChooser fc;
    private boolean[] checkResults = new boolean[5];
    private boolean finalResult = true;
    private TeacherForm tf;
    
    public TeacherFormController(TeacherForm tf) {
        this.tf = tf;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        JButton but = (JButton) ae.getSource();

        if (but.getText().equals("Add")) {
            
            // checkResult data from staff form
            DataValidation dv = new DataValidation();
            checkResults[0] = dv.checkName(tf.getFirstnameR().getText());
            checkResults[1] = dv.checkName(tf.getLastnameR().getText());
            checkResults[2] = dv.checkHomePhoneNumber(tf.getHomeNumR().getText());
            checkResults[3] = dv.checkCellPhoneNumber(tf.getPhoneNumR().getText());
            checkResults[4] = dv.checkEmail(tf.getEmailR().getText());
            
            for (int i = 0; i < checkResults.length; i++) {
                if(checkResults[i]==false){
                    finalResult = false;
                    System.out.println(i);
                }
            }
            
            if(finalResult){   
                Data data = new Data(TeacherForm.getInstance());
                data.saveTeacherData(Data.teacherList);
                TeacherForm.getInstance().dispose();
                ControlPanelForm.getInstance().setEnabled(true);
                ControlPanelForm.getInstance().setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "Invalid inputs");
                finalResult = true; // return finalResult to initial state
            }

        } else if (but.getText().equals("Cancel")) {
            ControlPanelForm cpf = ControlPanelForm.getInstance();
            TeacherForm teacher = TeacherForm.getInstance();
            teacher.dispose();
            cpf.setEnabled(true);
            cpf.setVisible(true);
        } else if (but.getText().equals("Browse")) {
            //Set up the file chooser.
            if (fc == null) {
                fc = new JFileChooser();

                //Add a custom file filter and disable the default
                //(Accept All) file filter.
                fc.addChoosableFileFilter(new ImageFilter());
                fc.setAcceptAllFileFilterUsed(false);

                //Add custom icons for file types.
                fc.setFileView(new ImageFileView());

                //Add the preview pane.
                fc.setAccessory(new ImagePreview(fc));
            }

            //Show it.
            TeacherForm teacher = TeacherForm.getInstance();
            int returnVal = fc.showDialog(fc,
                    "Attach");

            //Process the results.
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                System.out.println(fc.getSelectedFile().getPath());

                teacher.setImagePath(fc.getSelectedFile().getPath());
                teacher.TeacherInitialize();
            }

            //Reset the file chooser for the next time it's shown.
            fc.setSelectedFile(null);
        } else if (but.getText().equals("Assign")) {
        }
    }
}
