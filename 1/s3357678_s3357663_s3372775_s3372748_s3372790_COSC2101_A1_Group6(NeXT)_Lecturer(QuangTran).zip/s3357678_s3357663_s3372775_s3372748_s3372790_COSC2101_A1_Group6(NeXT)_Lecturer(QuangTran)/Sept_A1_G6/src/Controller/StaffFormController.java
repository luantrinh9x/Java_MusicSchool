package Controller;

import Model.Data;
import Model.DataValidation;
import View.*;
import java.awt.event.*;
import java.util.Observable;
import javax.swing.*;

public class StaffFormController extends Observable implements ActionListener {

    private JFileChooser fc;

    private StaffForm sf;
    private boolean[] checkResults = new boolean[8];
    private boolean finalResult = true;

    public StaffFormController(StaffForm sf){
        this.sf = sf;
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        JButton but = (JButton) ae.getSource();

        if (but.getText().equals("Add")) {

            DataValidation dv = new DataValidation();
            checkResults[0] = dv.checkName(sf.getFirstnameR().getText());
            checkResults[1] = dv.checkName(sf.getLastnameR().getText());
            checkResults[2] = dv.checkHomePhoneNumber(sf.getHomeNumR().getText());
            checkResults[3] = dv.checkCellPhoneNumber(sf.getPhoneNumR().getText());
            checkResults[4] = dv.checkEmail(sf.getEmailR().getText());
            checkResults[5] = dv.checkUserName(sf.getUserName().getText());
            checkResults[6] = dv.checkPassword(sf.getTypingPassword().getPassword());
            checkResults[7] = dv.checkRetypePassword(sf.getTypingPassword().getPassword(), sf.getRetypePassword().getPassword());

            for (int i = 0; i < checkResults.length; i++) {
                if (checkResults[i] == false) {
                    finalResult = false;
                }
            }

            if (finalResult) {
                Data data = new Data(StaffForm.getInstance());
                data.saveStaffData(Data.staffList);
                ControlPanelForm.getInstance().initialize();
                StaffForm.getInstance().dispose();
                ControlPanelForm.getInstance().setEnabled(true);
                ControlPanelForm.getInstance().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid inputs");
                finalResult = true; // return finalResult to initial state
            }
            
        } else if (but.getText().equals("Cancel")) {
            ControlPanelForm cpf = ControlPanelForm.getInstance();
            StaffForm staff = StaffForm.getInstance();
            staff.dispose();
            cpf.setEnabled(true);
            cpf.setVisible(true);
        } else if (but.getText().equals("Browse")) {
            //Set up the file chooser.
            if (fc == null) {
                fc = new JFileChooser();

                //Add a custom file filter and disable the default
                //(Accept All) file filter.
                fc.addChoosableFileFilter(new ImageFilter());
                fc.setAcceptAllFileFilterUsed(false);

                //Add custom icons for file types.
                fc.setFileView(new ImageFileView());

                //Add the preview pane.
                fc.setAccessory(new ImagePreview(fc));
            }

            //Show it.
            int returnVal = fc.showDialog(fc,
                    "Attach");

            //Process the results.
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                System.out.println(fc.getSelectedFile().getPath());
                StaffForm staff = StaffForm.getInstance();
                staff.setImagePath(fc.getSelectedFile().getPath());
                setModify();
            }

            //Reset the file chooser for the next time it's shown.
            fc.setSelectedFile(null);
        }
    }

    public void setModify() {
        setChanged();
        notifyObservers();
    }
}
