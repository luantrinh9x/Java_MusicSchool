package Controller;

import Model.Data;
import Model.DataValidation;
import Model.Student;
import View.ControlPanelForm;
import View.EnrollmentForm;
import View.StudentForm;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class StudentFormController implements ActionListener {

    private JFileChooser fc;
    private boolean[] checkResults = new boolean[5];
    private boolean finalResult = true;
    private StudentForm sf;

    public StudentFormController(StudentForm sf) {
        this.sf = sf;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        //Cast source
        JButton but = (JButton) ae.getSource();

        if (but.getText().equals("Add")) {

            // checkResult data from manaager form
            DataValidation dv = new DataValidation();
            checkResults[0] = dv.checkName(sf.getFirstnameR().getText());
            checkResults[1] = dv.checkName(sf.getLastnameR().getText());
            checkResults[2] = dv.checkHomePhoneNumber(sf.getHomeNumR().getText());
            checkResults[3] = dv.checkCellPhoneNumber(sf.getPhoneNumR().getText());
            checkResults[4] = dv.checkEmail(sf.getEmailR().getText());

            for (int i = 0; i < checkResults.length; i++) {
                if (checkResults[i] == false) {
                    finalResult = false;
                    System.out.println(i);
                }
            }

            if (finalResult) {
                Data data = new Data(StudentForm.getInstance());
                data.saveStudentData(Data.studentList);
                ControlPanelForm.getInstance().initialize();
                StudentForm.getInstance().dispose();
                data.setModify();
                ControlPanelForm.getInstance().setEnabled(true);
                ControlPanelForm.getInstance().setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "Invalid inputs");
                finalResult = true; // return finalResult to initial state
            }

        } else if (but.getText().equals("Cancel")) {
            ControlPanelForm cpf = ControlPanelForm.getInstance();
            StudentForm student = StudentForm.getInstance();
            student.dispose();
            cpf.setEnabled(true);
            cpf.setVisible(true);
        } else if (but.getText().equals("Browse")) {
            //Set up the file chooser.
            if (fc == null) {
                fc = new JFileChooser();

                //Add a custom file filter and disable the default
                //(Accept All) file filter.
                fc.addChoosableFileFilter(new ImageFilter());
                fc.setAcceptAllFileFilterUsed(false);

                //Add custom icons for file types.
                fc.setFileView(new ImageFileView());

                //Add the preview pane.
                fc.setAccessory(new ImagePreview(fc));
            }

            //Show it.
            int returnVal = fc.showDialog(fc,
                    "Attach");

            //Process the results.
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                System.out.println(fc.getSelectedFile().getPath());
                StudentForm student = StudentForm.getInstance();
                student.setImagePath(fc.getSelectedFile().getPath());
                student.studentInitialize();
            }

            //Reset the file chooser for the next time it's shown.
            fc.setSelectedFile(null);
        } else if (but.getText().equals("Enroll")) {
            EnrollmentForm.setUnique(null);
            EnrollmentForm enroll = EnrollmentForm.getInstance();
            String name = StudentForm.getInstance().getFirstnameR().getText() + " " + StudentForm.getInstance().getLastnameR().getText();
            enroll.getStudentName().setText(name);
            enroll.getIdR().setText(StudentForm.getInstance().getIdR().getText());
            enroll.initialize();
            StudentForm stu = StudentForm.getInstance();
            Student tempstu = Data.getCurrentStudentEnroll();
            tempstu = new Student(stu.getIdR().getText(), stu.getFirstnameR().getText(), stu.getLastnameR().getText(),
                    stu.getDobDay().getSelectedItem().toString(), stu.getDobMonth().getSelectedItem().toString(),
                    stu.getDobYear().getSelectedItem().toString(), stu.getGenderR().getSelectedItem().toString(),
                    stu.getPhoneNumCodeR().getSelectedItem().toString(),
                    stu.getPhoneNumR().getText(), stu.getHomeNumCodeR().getSelectedItem().toString(),
                    stu.getHomeNumR().getText(), stu.getEmailR().getText(), stu.getAddressR().getText(),
                    stu.getStatusR().getText(), stu.getInfoArea().getText(), stu.getUserType(), Data.getCurrentDate(),
                    stu.getClasses(), stu.getImagePath());

            stu.setEnabled(false);
        }
    }
}
