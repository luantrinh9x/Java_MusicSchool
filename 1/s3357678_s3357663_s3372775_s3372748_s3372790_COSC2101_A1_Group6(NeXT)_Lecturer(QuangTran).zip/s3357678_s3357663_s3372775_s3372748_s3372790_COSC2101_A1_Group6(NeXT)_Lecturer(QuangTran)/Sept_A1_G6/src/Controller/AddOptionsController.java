package Controller;

import Model.Data;
import View.*;
import java.awt.event.*;
import javax.swing.*;

public class AddOptionsController implements ActionListener, WindowListener {

    @Override
    public void actionPerformed(ActionEvent ae) {
        JButton but = (JButton) ae.getSource();
        switch (but.getText()) {
            case "Choose":
                AddOptions options = AddOptions.getInstance();

                if (options.getTypes().getSelectedItem().equals("Class")) {
                    ClassForm.setUnique(null);
                    ClassForm classForm = ClassForm.getInstance();
                    classForm.initialize();
                    Data data = new Data(classForm);
                } else if (options.getTypes().getSelectedItem().equals("Manager")) {
                    ManagerForm.setUnique(null);
                    ManagerForm manager = ManagerForm.getInstance();
                    manager.managerInitialize();
                    manager.setUserType("Manager");
                    Data data = new Data(manager);
                } else if (options.getTypes().getSelectedItem().equals("Staff")) {
                    StaffForm.setUnique(null);
                    StaffForm staff = StaffForm.getInstance();
                    staff.staffInitialize();
                    staff.setUserType("Staff");
                    Data data = new Data(staff);
                } else if (options.getTypes().getSelectedItem().equals("Teacher")) {
                    TeacherForm.setUnique(null);
                    TeacherForm teacher = TeacherForm.getInstance();
                    teacher.TeacherInitialize();
                    teacher.setUserType("Teacher");
                    Data data = new Data(teacher);
                } else if (options.getTypes().getSelectedItem().equals("Student")) {
                    StudentForm.setUnique(null);
                    StudentForm student = StudentForm.getInstance();
                    student.studentInitialize();
                    student.setUserType("Student");
                    Data data = new Data(student);
                }
                options.dispose();
                break;
            case "Cancel":
                AddOptions.getInstance().setVisible(false);
                AddOptions.getInstance().dispose();
                ControlPanelForm.getInstance().setEnabled(true);
                ControlPanelForm.getInstance().setVisible(true);
                break;
        }
    }

    @Override
    public void windowOpened(WindowEvent e) {
    }

    @Override
    public void windowClosing(WindowEvent e) {
        ControlPanelForm.getInstance().setEnabled(true);
        ControlPanelForm.getInstance().setVisible(true);
    }

    @Override
    public void windowClosed(WindowEvent e) {
    }

    @Override
    public void windowIconified(WindowEvent e) {
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
    }

    @Override
    public void windowActivated(WindowEvent e) {
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
    }
}
