/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Data;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Phi Hung
 */
public class CopyClassController implements ActionListener {

    private String id;

    @Override
    public void actionPerformed(ActionEvent ae) {
        System.out.println(id);
        if (id != null) {
            Data data = new Data();
            data.copyClasses(id);
        }
    }

    public void renew() {
        this.id = new String();
    }

    public void setId(String id) {
        this.id = id;
    }
}
