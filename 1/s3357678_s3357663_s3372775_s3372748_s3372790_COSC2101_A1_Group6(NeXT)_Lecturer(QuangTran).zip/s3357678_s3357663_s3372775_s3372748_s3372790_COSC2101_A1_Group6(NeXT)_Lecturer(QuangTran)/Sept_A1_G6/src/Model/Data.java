package Model;

import Controller.ControlPanelFormController;
import View.ClassForm;
import View.ManagerForm;
import View.StaffForm;
import View.StudentForm;
import View.TeacherForm;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.*;
import View.ControlPanelFormUtilities.RightPanel;

public class Data extends Observable {

    private static String managerFile = "Manager.bin";
    private static String staffFile = "Staff.bin";
    private static String teacherFile = "Teacher.bin";
    private static String studentFile = "Student.bin";
    private static String classFile = "Class.bin";
    public static ArrayList<Teacher> teacherList = new ArrayList<>();
    public static ArrayList<Classes> classList = new ArrayList<>();
    public static ArrayList<Manager> managerList = new ArrayList<>();
    public static ArrayList<Manager> deleteManagerList = new ArrayList<>();
    public static ArrayList<Staff> staffList = new ArrayList<>();
    public static ArrayList<Student> studentList = new ArrayList<>();
    private ManagerForm managerForm;
    private Manager man;
    private StaffForm staffForm;
    private Staff sta;
    private StudentForm studentForm;
    private Student stu;
    private TeacherForm teacherForm;
    private Teacher tea;
    private ClassForm classForm;
    private Classes cla;
    private static User currentUser;
    private static User currentClickUser;
    private static Student currentStudentEnroll;

    public Data() {
    }

    public Data(ManagerForm manager) {
        this.managerForm = manager;
    }

    public Data(ClassForm classForm) {
        this.classForm = classForm;
    }

    public Data(StaffForm staffForm) {
        this.staffForm = staffForm;
    }

    public Data(StudentForm studentForm) {
        this.studentForm = studentForm;
    }

    public Data(TeacherForm teacherForm) {
        this.teacherForm = teacherForm;
    }

    public void saveManagerData(ArrayList<Manager> managerList) {

        man = new Manager(managerForm.getIdR().getText(), managerForm.getFirstnameR().getText(),
                managerForm.getLastnameR().getText(), managerForm.getDobDay().getSelectedItem().toString(),
                managerForm.getDobMonth().getSelectedItem().toString(), managerForm.getDobYear().getSelectedItem().toString(),
                managerForm.getGenderR().getSelectedItem().toString(), managerForm.getPhoneNumCodeR().getSelectedItem().toString(),
                managerForm.getPhoneNumR().getText(), managerForm.getHomeNumCodeR().getSelectedItem().toString(),
                managerForm.getHomeNumR().getText(), managerForm.getEmailR().getText(), managerForm.getAddressR().getText(),
                managerForm.getStatusR().getText(), managerForm.getInfoArea().getText(), managerForm.getUserType(), getCurrentDate(),
                managerForm.getUserName().getText(), managerForm.getTypingPassword().getPassword(), managerForm.getRetypePassword().getPassword(), managerForm.getImagePath());
        System.out.println(managerForm.getImagePath());
        managerList.add(man);

        ControlPanelFormController.rightPanelLoadManager();
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(managerFile))) {
            {
                os.writeObject(managerList);
                System.out.println("after write" + managerList);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Save to Manager File", "Notice", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void saveManager(ArrayList<Manager> managerList) {

        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(managerFile))) {
            {
                os.writeObject(managerList);
                System.out.println("after write" + managerList);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Save to Manager File", "Notice", JOptionPane.INFORMATION_MESSAGE);
        }
        ControlPanelFormController.rightPanelLoadManager();
    }

    public void saveStaffData(ArrayList<Staff> staffList) {
        sta = new Staff(staffForm.getIdR().getText(), staffForm.getFirstnameR().getText(),
                staffForm.getLastnameR().getText(), staffForm.getDobDay().getSelectedItem().toString(),
                staffForm.getDobMonth().getSelectedItem().toString(), staffForm.getDobYear().getSelectedItem().toString(),
                staffForm.getGenderR().getSelectedItem().toString(), staffForm.getPhoneNumCodeR().getSelectedItem().toString(),
                staffForm.getPhoneNumR().getText(), staffForm.getHomeNumCodeR().getSelectedItem().toString(),
                staffForm.getHomeNumR().getText(), staffForm.getEmailR().getText(), staffForm.getAddressR().getText(),
                staffForm.getStatusR().getText(), staffForm.getInfoArea().getText(), staffForm.getUserType(), getCurrentDate(),
                staffForm.getUserName().getText(), staffForm.getTypingPassword().getPassword(), staffForm.getRetypePassword().getPassword(), staffForm.getImagePath());
        staffList.add(sta);

        ControlPanelFormController.rightPanelLoadStaff();
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(staffFile))) {
            {
                os.writeObject(staffList);
                System.out.println("after write" + staffList);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Save to Student File", "Notice", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void saveStaff(ArrayList<Staff> staffList) {
        ControlPanelFormController.rightPanelLoadStaff();
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(staffFile))) {
            {
                os.writeObject(staffList);
                System.out.println("after write" + staffList);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Save to Student File", "Notice", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void saveTeacherData(ArrayList<Teacher> teacherList) {
        String[] tempSkill = new String[10];
        String[] tempClass = new String[10];
        int count = 0;
        for (int i = 0; i < teacherForm.getNumberOfSkill(); i++) {
            if (teacherForm.getAllSkill()[i].isSelected()) {
                tempSkill[count] = teacherForm.getAllSkill()[i].getText();
                count++;
            }
        }

//        System.arraycopy(teacherForm.getc, count, sta, count, count);

        tea = new Teacher(teacherForm.getIdR().getText(), teacherForm.getFirstnameR().getText(),
                teacherForm.getLastnameR().getText(), teacherForm.getDobDay().getSelectedItem().toString(),
                teacherForm.getDobMonth().getSelectedItem().toString(), teacherForm.getDobYear().getSelectedItem().toString(),
                teacherForm.getGenderR().getSelectedItem().toString(), teacherForm.getPhoneNumCodeR().getSelectedItem().toString(),
                teacherForm.getPhoneNumR().getText(), teacherForm.getHomeNumCodeR().getSelectedItem().toString(),
                teacherForm.getHomeNumR().getText(), teacherForm.getEmailR().getText(), teacherForm.getAddressR().getText(),
                teacherForm.getStatusR().getText(), teacherForm.getInfoArea().getText(), teacherForm.getUserType(), getCurrentDate(), tempSkill, tempClass, teacherForm.getImagePath());
        teacherList.add(tea);

        ControlPanelFormController.rightPanelLoadTeacher();
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(teacherFile))) {
            {
                os.writeObject(teacherList);
                System.out.println("after write" + teacherList);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Save to Teacher File", "Notice", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void saveTeacher(ArrayList<Teacher> teacherList) {
        ControlPanelFormController.rightPanelLoadTeacher();
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(teacherFile))) {
            {
                os.writeObject(teacherList);
                System.out.println("after write" + teacherList);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Save to Teacher File", "Notice", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void saveStudentData(ArrayList<Student> studentList) {

        stu = new Student(studentForm.getIdR().getText(), studentForm.getFirstnameR().getText(),
                studentForm.getLastnameR().getText(), studentForm.getDobDay().getSelectedItem().toString(),
                studentForm.getDobMonth().getSelectedItem().toString(), studentForm.getDobYear().getSelectedItem().toString(),
                studentForm.getGenderR().getSelectedItem().toString(), studentForm.getPhoneNumCodeR().getSelectedItem().toString(),
                studentForm.getPhoneNumR().getText(), studentForm.getHomeNumCodeR().getSelectedItem().toString(),
                studentForm.getHomeNumR().getText(), studentForm.getEmailR().getText(), studentForm.getAddressR().getText(),
                studentForm.getStatusR().getText(), studentForm.getInfoArea().getText(), studentForm.getUserType(), getCurrentDate(),
                studentForm.getClasses(), studentForm.getImagePath());
        studentList.add(stu);

        ControlPanelFormController.rightPanelLoadStudent();
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(studentFile))) {
            {
                os.writeObject(studentList);
                System.out.println("after write" + studentList);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Save to Student File", "Notice", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void saveStudent(ArrayList<Student> studentList) {
        ControlPanelFormController.rightPanelLoadStudent();
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(studentFile))) {
            {
                os.writeObject(studentList);
                System.out.println("after write" + studentList);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Save to Student File", "Notice", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void saveClassData(ArrayList<Classes> classList) {
//        String Id, String classCode, String classType, String className, String startDate, String endDate,
//            String startTime, String endTime, String room
        cla = new Classes(classForm.getIdText().getText(), classForm.getCodeText().getText(),
                classForm.getTypeCB().getSelectedItem().toString(), classForm.getNameText().getText(),
                classForm.getStartDate(), classForm.getEndDate(),
                classForm.getMon().getText(), classForm.getTue().getText(), classForm.getWed().getText(),
                classForm.getThu().getText(), classForm.getFri().getText(), classForm.getSat().getText(),
                classForm.getMonStartTime().getSelectedItem().toString(),
                classForm.getTueStartTime().getSelectedItem().toString(),
                classForm.getWedStartTime().getSelectedItem().toString(),
                classForm.getThuStartTime().getSelectedItem().toString(),
                classForm.getFriStartTime().getSelectedItem().toString(),
                classForm.getSatStartTime().getSelectedItem().toString(),
                classForm.getMonEndTime().getSelectedItem().toString(),
                classForm.getTueEndTime().getSelectedItem().toString(),
                classForm.getWedEndTime().getSelectedItem().toString(),
                classForm.getThuEndTime().getSelectedItem().toString(),
                classForm.getFriEndTime().getSelectedItem().toString(),
                classForm.getSatEndTime().getSelectedItem().toString(),
                classForm.getMonRoom().getSelectedItem().toString(),
                classForm.getTueRoom().getSelectedItem().toString(),
                classForm.getWedRoom().getSelectedItem().toString(),
                classForm.getThuRoom().getSelectedItem().toString(),
                classForm.getFriRoom().getSelectedItem().toString(),
                classForm.getSatRoom().getSelectedItem().toString(),
                getCurrentDate());


        classList.add(cla);
        ControlPanelFormController.rightPanelLoadClass();
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(classFile))) {
            {
                os.writeObject(classList);
                System.out.println("after write" + classList);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Save to Student File", "Notice", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void saveClass(ArrayList<Classes> classList) {
        ControlPanelFormController.rightPanelLoadClass();
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(classFile))) {
            {
                os.writeObject(classList);
                System.out.println("after write" + classList);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Save to Student File", "Notice", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    //load Manager
    public ArrayList<Manager> loadManagerData() {
        try {
            FileInputStream istream = new FileInputStream(managerFile);
            ObjectInputStream is = new ObjectInputStream(istream);
            try {
                while (istream.available() > 0) // check if the file stream is at the end
                {
                    managerList = (ArrayList<Manager>) is.readObject();
                    System.out.println(managerList);
                }

                is.close();
            } catch (ClassNotFoundException ex) {
            }
        } catch (IOException ex) {
        }
        return managerList;
    }

    //load Staff
    public ArrayList<Staff> loadStaffData() {
        try {
            FileInputStream istream = new FileInputStream(staffFile);
            ObjectInputStream is = new ObjectInputStream(istream);
            try {
                while (istream.available() > 0) // check if the file stream is at the end
                {
                    staffList = (ArrayList<Staff>) is.readObject();
                    System.out.println(staffList);
                }

                is.close();
            } catch (ClassNotFoundException ex) {
            }
        } catch (IOException ex) {
        }
        return staffList;
    }

    //load Student
    public ArrayList<Student> loadStudentData() {
        try {
            FileInputStream istream = new FileInputStream(studentFile);
            ObjectInputStream is = new ObjectInputStream(istream);
            try {
                while (istream.available() > 0) // check if the file stream is at the end
                {
                    studentList = (ArrayList<Student>) is.readObject();
                    System.out.println(studentList);
                }

                is.close();
            } catch (ClassNotFoundException ex) {
            }
        } catch (IOException ex) {
        }
        return studentList;
    }

    //load Teacher
    public ArrayList<Teacher> loadTeacherData() {
        try {
            FileInputStream istream = new FileInputStream(teacherFile);
            ObjectInputStream is = new ObjectInputStream(istream);
            try {
                while (istream.available() > 0) // check if the file stream is at the end
                {
                    teacherList = (ArrayList<Teacher>) is.readObject();
                    System.out.println(teacherList);
                }

                is.close();
            } catch (ClassNotFoundException ex) {
            }
        } catch (IOException ex) {
        }
        return teacherList;
    }

    //load Class
    public ArrayList<Classes> loadClassData() {
        try {
            FileInputStream istream = new FileInputStream(classFile);
            ObjectInputStream is = new ObjectInputStream(istream);
            try {
                while (istream.available() > 0) // check if the file stream is at the end
                {
                    classList = (ArrayList<Classes>) is.readObject();
                    System.out.println(classList);
                }

                is.close();
            } catch (ClassNotFoundException ex) {
            }
        } catch (IOException ex) {
        }
        return classList;
    }

    public static String getCurrentDate() {
        String current = "";
        Calendar currentDate = Calendar.getInstance(); //Get the current date
        SimpleDateFormat formatter = new SimpleDateFormat("dd,MMM yyyy"); //format it as per your requirement
        current = formatter.format(currentDate.getTime());
        return current;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User currentUser) {
        Data.currentUser = currentUser;
    }

    public void detele(ArrayList<String> ids) {

        char cha = ids.get(0).charAt(0);
        for (int i = 0; i < ids.size(); i++) {
            System.out.println("Id: " + ids.get(i));
            switch (cha) {
                case 'M':
                    for (int j = 0; j < Data.managerList.size(); j++) {

                        if (ids.get(i).equals(Data.managerList.get(j).getID())) {
                            Data.managerList.remove(j);
                            break;
                        }
                    }
                    System.out.println("Delete Manager Working");
                    saveManager(Data.managerList);
                    break;
                case 'V':
                    for (int j = 0; j < Data.teacherList.size(); j++) {

                        if (ids.get(i).equals(Data.teacherList.get(j).getID())) {
                            Data.teacherList.remove(j);
                            break;
                        }
                    }
                    System.out.println("Delete Staff Working");
                    saveTeacher(Data.teacherList);
                    break;
                case 'T':
                    for (int j = 0; j < Data.staffList.size(); j++) {

                        if (ids.get(i).equals(Data.staffList.get(j).getID())) {
                            Data.staffList.remove(j);
                            break;
                        }
                    }
                    System.out.println("Delete Teacher Working");
                    saveStaff(Data.staffList);
                    break;
                case 'S':
                    for (int j = 0; j < Data.studentList.size(); j++) {

                        if (ids.get(i).equals(Data.studentList.get(j).getID())) {
                            Data.studentList.remove(j);
                            break;
                        }
                    }
                    System.out.println("Delete Student Working");
                    saveStudent(Data.studentList);
                    break;
                case 'C':
                    for (int j = 0; j < Data.classList.size(); j++) {

                        if (ids.get(i).equals(Data.classList.get(j).getId())) {
                            Data.classList.remove(j);
                            break;
                        }
                    }
                    System.out.println("Delete Class Working");
                    saveClass(Data.classList);
                    break;
            }
        }

    }

    public void Edit(String id) {

        char cha = id.charAt(0);
        System.out.println("Id: " + id.charAt(0));
        switch (cha) {
            case 'M':
                for (int j = 0; j < Data.managerList.size(); j++) {

                    if (id.equals(Data.managerList.get(j).getID())) {


                        ManagerForm.setUnique(null);
                        ManagerForm manager = ManagerForm.getInstance();
//                            ManagerForm.getInstance();
//                            Manager temp = Data.managerList.get(j);
                        manager.managerInitialize();
                        manager.setTitle("Edit Manager");
                        System.out.println("ManagerForm");
                        System.out.println(Data.managerList.get(j).getID());
                        manager.idR.setText(Data.managerList.get(j).getID());
                        manager.getFirstnameR().setText(Data.managerList.get(j).getFirstName());
                        manager.getLastnameR().setText(Data.managerList.get(j).getLastName());
                        manager.getDobDay().setSelectedItem(Data.managerList.get(j).getDobDate());
                        manager.getDobMonth().setSelectedItem(Data.managerList.get(j).getDobMonth());
                        manager.getDobYear().setSelectedItem(Data.managerList.get(j).getDobYear());
                        manager.getEmailR().setText(Data.managerList.get(j).getEmail());
                        manager.getAddressR().setText(Data.managerList.get(j).getAddress());
                        manager.getGenderR().setSelectedItem(Data.managerList.get(j).getGender());
                        manager.getHomeNumCodeR().setSelectedItem(Data.managerList.get(j).getHomeNoCode());
                        manager.getHomeNumR().setText(Data.managerList.get(j).getHomeNo());
                        manager.getDescription().setText(Data.managerList.get(j).getDescription());
                        manager.getUserName().setText(Data.managerList.get(j).getUsername());
                        manager.getTypingPassword().setText(Data.managerList.get(j).getTypingPassword().toString());
                        manager.getRetypePassword().setText(Data.managerList.get(j).getRetype().toString());
                        managerList.remove(j);
                        break;
                    }
                }
                saveManager(Data.managerList);
                break;
            case 'V':
                for (int j = 0; j < Data.teacherList.size(); j++) {

                    if (id.equals(Data.teacherList.get(j).getID())) {
                        TeacherForm.setUnique(null);
                        TeacherForm teacher = TeacherForm.getInstance();
//                            ManagerForm.getInstance();
//                            Manager temp = Data.managerList.get(j);
                        teacher.TeacherInitialize();
                        teacher.setTitle("Edit Teacher");

                        System.out.println(Data.teacherList.get(j).getID());
                        teacher.idR.setText(Data.teacherList.get(j).getID());
                        teacher.getFirstnameR().setText(Data.teacherList.get(j).getFirstName());
                        teacher.getLastnameR().setText(Data.teacherList.get(j).getLastName());
                        teacher.getDobDay().setSelectedItem(Data.teacherList.get(j).getDobDate());
                        teacher.getDobMonth().setSelectedItem(Data.teacherList.get(j).getDobMonth());
                        teacher.getDobYear().setSelectedItem(Data.teacherList.get(j).getDobYear());
                        teacher.getEmailR().setText(Data.teacherList.get(j).getEmail());
                        teacher.getAddressR().setText(Data.teacherList.get(j).getAddress());
                        teacher.getGenderR().setSelectedItem(Data.teacherList.get(j).getGender());
                        teacher.getHomeNumCodeR().setSelectedItem(Data.teacherList.get(j).getHomeNoCode());
                        teacher.getHomeNumR().setText(Data.teacherList.get(j).getHomeNo());
                        teacher.getDescription().setText(Data.teacherList.get(j).getDescription());
                        teacherList.remove(j);
                        break;
                    }
                }
                saveTeacher(Data.teacherList);
                break;
            case 'T':
                for (int j = 0; j < Data.staffList.size(); j++) {

                    if (id.equals(Data.staffList.get(j).getID())) {
                        StaffForm.setUnique(null);
                        StaffForm staff = StaffForm.getInstance();
//                            ManagerForm.getInstance();
//                            Manager temp = Data.managerList.get(j);
                        staff.staffInitialize();
                        staff.setTitle("Edit Staff");
                        System.out.println("ManagerForm");
                        System.out.println(Data.staffList.get(j).getID());
                        staff.idR.setText(Data.staffList.get(j).getID());
                        staff.getFirstnameR().setText(Data.staffList.get(j).getFirstName());
                        staff.getLastnameR().setText(Data.staffList.get(j).getLastName());
                        staff.getDobDay().setSelectedItem(Data.staffList.get(j).getDobDate());
                        staff.getDobMonth().setSelectedItem(Data.staffList.get(j).getDobMonth());
                        staff.getDobYear().setSelectedItem(Data.staffList.get(j).getDobYear());
                        staff.getEmailR().setText(Data.staffList.get(j).getEmail());
                        staff.getAddressR().setText(Data.staffList.get(j).getAddress());
                        staff.getGenderR().setSelectedItem(Data.staffList.get(j).getGender());
                        staff.getHomeNumCodeR().setSelectedItem(Data.staffList.get(j).getHomeNoCode());
                        staff.getHomeNumR().setText(Data.staffList.get(j).getHomeNo());
                        staff.getDescription().setText(Data.staffList.get(j).getDescription());
                        staff.getUserName().setText(Data.staffList.get(j).getUsername());
                        staff.getTypingPassword().setText(Data.staffList.get(j).getTypingPassword().toString());
                        staff.getRetypePassword().setText(Data.staffList.get(j).getRetype().toString());
                        staffList.remove(j);
                        break;
                    }
                }
                saveStaff(Data.staffList);
                break;
            case 'S':
                for (int j = 0; j < Data.studentList.size(); j++) {

                    if (id.equals(Data.studentList.get(j).getID())) {
                        StudentForm.setUnique(null);
                        StudentForm student = StudentForm.getInstance();
//                            ManagerForm.getInstance();
//                            Manager temp = Data.managerList.get(j);
                        student.studentInitialize();
                        student.setTitle("Edit Staff");

                        System.out.println(Data.studentList.get(j).getID());
                        student.idR.setText(Data.studentList.get(j).getID());
                        student.getFirstnameR().setText(Data.studentList.get(j).getFirstName());
                        student.getLastnameR().setText(Data.studentList.get(j).getLastName());
                        student.getDobDay().setSelectedItem(Data.studentList.get(j).getDobDate());
                        student.getDobMonth().setSelectedItem(Data.studentList.get(j).getDobMonth());
                        student.getDobYear().setSelectedItem(Data.studentList.get(j).getDobYear());
                        student.getEmailR().setText(Data.studentList.get(j).getEmail());
                        student.getAddressR().setText(Data.studentList.get(j).getAddress());
                        student.getGenderR().setSelectedItem(Data.studentList.get(j).getGender());
                        student.getHomeNumCodeR().setSelectedItem(Data.studentList.get(j).getHomeNoCode());
                        student.getHomeNumR().setText(Data.studentList.get(j).getHomeNo());
                        student.getDescription().setText(Data.studentList.get(j).getDescription());
                        studentList.remove(j);
                        break;
                    }
                }
                saveStudent(Data.studentList);
                break;
            case 'C':
                for (int j = 0; j < Data.classList.size(); j++) {

                    if (id.equals(Data.classList.get(j).getId())) {
                        ClassForm.setUnique(null);
                        ClassForm classForm = ClassForm.getInstance();
//                            ManagerForm.getInstance();
//                            Manager temp = Data.managerList.get(j);
                        classForm.initialize();
                        classForm.setTitle("Edit Class");
                        System.out.println("ManagerForm");
                        System.out.println(Data.classList.get(j).getId());
                        classForm.getIdText().setText(Data.classList.get(j).getId());
                        classForm.getNameText().setText(Data.classList.get(j).getClassName());
                        classForm.getCodeText().setText(Data.classList.get(j).getClassCode());
                        classForm.getAtCB().setSelectedItem(Data.classList.get(j).getRooms());

//                            classForm.getCodeText().setSelectedItem(Data.managerList.get(j).getDobMonth());
//                            classForm.getDobYear().setSelectedItem(Data.managerList.get(j).getDobYear());
//                            classForm.getEmailR().setText(Data.managerList.get(j).getEmail());
//                            classForm.getAddressR().setText(Data.managerList.get(j).getAddress());
//                            classForm.getGenderR().setSelectedItem(Data.managerList.get(j).getGender());
//                            classForm.getHomeNumCodeR().setSelectedItem(Data.managerList.get(j).getHomeNoCode());
//                            classForm.getHomeNumR().setText(Data.managerList.get(j).getHomeNo());
//                            classForm.getDescription().setText(Data.managerList.get(j).getDescription());
//                            classForm.getUserName().setText(Data.managerList.get(j).getUsername());
//                            classForm.getTypingPassword().setText(Data.managerList.get(j).getTypingPassword().toString());
//                            classForm.getRetypePassword().setText(Data.managerList.get(j).getRetype().toString());
                        classList.remove(j);
                        break;
                    }
                }
                saveClass(Data.classList);
                break;
        }

    }

    public void activateButton(ArrayList<String> ids) {

        char cha = ids.get(0).charAt(0);
        for (int i = 0; i < ids.size(); i++) {
            System.out.println("Id: " + ids.get(i));
            switch (cha) {
                case 'M':
                    for (int j = 0; j < Data.managerList.size(); j++) {

                        if (ids.get(i).equals(Data.managerList.get(j).getID())) {

                            System.out.println("Status before:");
                            System.out.println(Data.managerList.get(j).getStatus());
                            if (Data.managerList.get(j).getStatus().equalsIgnoreCase("Activate")) {
                                Data.managerList.get(j).setStatus("Deactivate");
                                System.out.println("Status after:");
                                System.out.println(Data.managerList.get(j).getStatus());
                            } else {
                                Data.managerList.get(j).setStatus("Activate");
                                System.out.println("Status after:");
                                System.out.println(Data.managerList.get(j).getStatus());
                            }
                            System.out.println("Inside change Activate/Deactivate");
                            break;
                        }
                    }
                    System.out.println("Working");
                    saveManager(Data.managerList);
                    break;
                case 'V':
                    for (int j = 0; j < Data.teacherList.size(); j++) {

                        if (ids.get(i).equals(Data.teacherList.get(j).getID())) {
                            if (Data.teacherList.get(j).getStatus().equalsIgnoreCase("Activate")) {
                                Data.teacherList.get(j).setStatus("Deactivate");
                                System.out.println("Button Working");
                            } else {
                                Data.teacherList.get(j).setStatus("Activate");

                            }
                            System.out.println("Inside change Activate/Deactivate");
                            break;
                        }
                    }
                    saveTeacher(Data.teacherList);
                    break;
                case 'T':
                    for (int j = 0; j < Data.staffList.size(); j++) {

                        if (ids.get(i).equals(Data.staffList.get(j).getID())) {
                            if (Data.staffList.get(j).getStatus().equalsIgnoreCase("Activate")) {
                                Data.staffList.get(j).setStatus("Deactivate");
                            } else {
                                Data.staffList.get(j).setStatus("Activate");
                            }
                            System.out.println("Inside change Activate/Deactivate");
                            break;
                        }
                    }
                    saveStaff(Data.staffList);
                    break;
                case 'S':
                    for (int j = 0; j < Data.studentList.size(); j++) {

                        if (ids.get(i).equals(Data.studentList.get(j).getID())) {
                            if (Data.studentList.get(j).getStatus().equalsIgnoreCase("Activate")) {
                                Data.studentList.get(j).setStatus("Deactivate");
                            } else {
                                Data.studentList.get(j).setStatus("Activate");
                            }
                            System.out.println("Inside change Activate/Deactivate");
                            break;
                        }
                    }
                    saveStudent(Data.studentList);
                    break;
                default:
            }
        }

    }

    public void copyClasses(String id) {
        for (int j = 0; j < Data.classList.size(); j++) {

            if (Data.classList.get(j).getId().equalsIgnoreCase(id)) {
                System.out.println("Working");
                System.out.println(Data.classList.get(j).getId());
                Classes temp = Data.classList.get(j);
                String newId = Data.classList.get(Data.classList.size() - 1).getId();
                int num = Integer.parseInt(newId.substring(1));
                num++;
                temp.setId("C" + num);
                Data.classList.add(temp);

                break;
            }
            saveClass(Data.classList);
        }
    }

    public static User getCurrentClickUser() {
        return currentClickUser;
    }

    public static void setCurrentClickUser(User currentClickUser) {
        Data.currentClickUser = currentClickUser;
    }

    public static Student getCurrentStudentEnroll() {
        return currentStudentEnroll;
    }

    public static void setCurrentStudentEnroll(Student currentStudentEnroll) {
        Data.currentStudentEnroll = currentStudentEnroll;
    }

    public void setModify() {
        setChanged();
        notifyObservers();
    }
}
