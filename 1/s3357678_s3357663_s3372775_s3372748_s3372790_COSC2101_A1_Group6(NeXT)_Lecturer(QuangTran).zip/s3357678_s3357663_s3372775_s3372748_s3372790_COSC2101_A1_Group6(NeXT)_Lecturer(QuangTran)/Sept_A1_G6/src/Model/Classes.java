package Model;

import java.io.Serializable;

public class Classes implements Serializable {

    private String Id;
    private String classCode;
    private String classType;
    private String className;
    private String startDate;
    private String endDate;
    private String currentDate;
    private String classLabel = "Class";
//    private String tuitionFee;
//    private String teacher;
    private String[] days = new String[6];
    private String[] froms = new String[6];
    private String[] tos = new String[6];
    private String[] rooms = new String[6];

    public Classes() {
    }
    
    

    public Classes(String Id, String classCode, String classType, String className,
            String startDate, String endDate, String day0, String day1, String day2, String day3, String day4, String day5, String froms0, String froms1, String froms2, String froms3, String froms4, String froms5, String to0, String to1, String to2, String to3, String to4, String to5, String room0, String room1, String room2, String room3, String room4, String room5, String currentDate) {

        this.Id = Id;
        this.classCode = classCode;
        this.classType = classType;
        this.className = className;
        this.startDate = startDate;
        this.endDate = endDate;
        this.currentDate = currentDate;

        // assign endtime into days array "days"
        days[0] = day0;
        days[1] = day1;
        days[2] = day2;
        days[3] = day3;
        days[4] = day4;
        days[5] = day5;

        // assign endtime into start time array "froms"
        froms[0] = froms0;
        froms[1] = froms1;
        froms[2] = froms2;
        froms[3] = froms3;
        froms[4] = froms4;
        froms[5] = froms5;

        // assign endtime into endtime array "tos"
        tos[0] = to0;
        tos[1] = to1;
        tos[2] = to2;
        tos[3] = to3;
        tos[4] = to4;
        tos[5] = to5;

        // assign rooms into room array
        rooms[0] = room0;
        rooms[1] = room1;
        rooms[2] = room2;
        rooms[3] = room3;
        rooms[4] = room4;
        rooms[5] = room5;
//        this.tuitionFee = tuitionFee;
//        this.teacher = teacher;
    }

    public String[] getDays() {
        return days;
    }

    public String[] getFroms() {
        return froms;
    }

    public String[] getTos() {
        return tos;
    }

    public String[] getRooms() {
        return rooms;
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    public String getClassType() {
        return classType;
    }

    public void setClassType(String classType) {
        this.classType = classType;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }
//
//    public String getTeacher() {
//        return teacher;
//    }
//
//    public void setTeacher(String teacher) {
//        this.teacher = teacher;
//    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getId() {
        return Id;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    public String getClassLabel() {
        return classLabel;
    }

    public void setClassLabel(String classLabel) {
        this.classLabel = classLabel;
    }

    public void setId(String Id) {
        this.Id = Id;
    }
    
}
