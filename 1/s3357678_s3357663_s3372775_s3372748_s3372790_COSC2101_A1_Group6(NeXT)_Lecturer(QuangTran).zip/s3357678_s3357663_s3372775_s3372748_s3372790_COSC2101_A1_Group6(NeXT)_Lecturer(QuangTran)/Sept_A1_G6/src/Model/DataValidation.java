package Model;

public class DataValidation {

    private final boolean INVALID = false;
    private final boolean VALID = true;

    /* this methods checks to ensure that:
     *      1. username must not be empty
     *      2. username must has not already taken by someone else
     * the methods return VALID if both conditions are met
     * else returns INVALID
     */
    public boolean checkUserName(String username) {
        
        // go through all managers to check for any identical username
        for (int i = 0; i < Data.managerList.size(); i++) {
            if(username.equals(Data.managerList.get(i).getUsername())){
                System.out.println("username taken !");
                return INVALID;
            }
        }
        // go through all staffs to check for any identical username
        for (int i = 0; i < Data.staffList.size(); i++) {
            if(username.equals(Data.staffList.get(i).getUsername())){
                return INVALID;
            }
        }
        return VALID;
    }

    /* this method takes in name and check to see if:  
     *      1. the name is empty
     *      2. the name start with space/might contain only space 
     * the method returns INVALID if any of the above happens
     * else the method will return VALID
     */
    public boolean checkName(String name) {

        if (name.isEmpty()) {
            System.out.println("check name not success");
            return INVALID;
        }
        if (name.startsWith(" ")) {
            System.out.println("check name not success");
            return INVALID;
        }
        System.out.println("check name success");
        return VALID;
    }

    /* this method takes in a time string, 
     * then convert and return it as an int value 
     * the value will be converted as follow:
     *      1. 9:00: String -> 9: int
     *      2. 9:30: String -> 9.5: int
     * method returns total hour and min
     */
    public double processTimeString(String time) {
        String[] times = time.split(":");
        int hour = Integer.parseInt(times[0]);
        double min = Integer.parseInt(times[1]);
        if (min == 30) {
            min = .5;
        }
        double total = hour + min;
        return total;
    }

    /* this method takes in th class times and check to see if:
     *      1. start and end time are the same(times difference is 0)
     *      2. class takes longer than 2 hours(times difference is greater than 2)
     *      3. end time is earlier than start time(times difference is a negative)
     * the method returns INVALID if any conditions above happens
     * else the method will return VALID
     */
    public boolean checkClassTime(String start, String end) {
        double startTime;
        double endTime;
        double difference;

        startTime = processTimeString(start);
        endTime = processTimeString(end);
        difference = startTime - endTime;

        if (difference == 0 || difference > 2 || difference < 0) {
            return INVALID;
        }
        return VALID;
    }

    /* this method checks regex for home phone number:
     *      1. must be number only
     *      2. length must be 8
     * method returns VALID if phone number satisfy above conditions
     * else returns INVALID
     */
    public boolean checkHomePhoneNumber(String number) {
        if (number.matches("^[0-9]{8}$")) {
            System.out.println("check home number success");
            return VALID;
        }
        System.out.println("check home number not success");
        return INVALID;
    }

    /* this method checks regex for cell phone number:
     *      1. must be number only
     *      2. length must be 8
     * method returns VALID if phone number satisfy above conditions
     * else returns INVALID
     */
    public boolean checkCellPhoneNumber(String number) {
        if (number.matches("^[0-9]{9,10}$")) {
            System.out.println("check cell number success");
            return VALID;
        }
        System.out.println("check cell number not success");
        return INVALID;
    }

    /* this method checks regex for e-mail: 
     *      1. email must have format: abc@example.com
     *  method returns VALID if the mail matches the expression above
     *  else returns INVALID
     */
    public boolean checkEmail(String email) {
        if (email.matches("^[a-zA-z0-9]+(@)[a-z]+(.com)$")) {
            System.out.println("check email success");
            return VALID;
        }
        System.out.println("check email not success");
        return INVALID;
    }

    /* this method checks password requirements, password has to : 
     *      be at least 8 character long
     *      contain at least 1 upper case character
     *      contain at least 1 number
     *      contain at least 1 special character
     * method returns INVALID if any of the requirement above is not met
     * else returns VALID
     */
    public boolean checkPassword(char[] pw){
        
        boolean isUpper = false;
        boolean isLower = false;
        boolean isDigit = false;
        boolean isSpecs = false;
        char[] specs = {'!','@','#','$','%','^','&','*'};
        
        // check the length of the password
        if(pw.length < 8){
            System.out.println("not enough length");
            return INVALID;
        }
        
        for (int i = 0; i < pw.length; i++) {
            if(Character.isUpperCase(pw[i])){ // any char upper case ?
                isUpper = true;
            }
            if(Character.isLowerCase(pw[i])){ // any char lower case ?
                isLower = true;
            }
            if(Character.isDigit(pw[i])){ // any char a number ?
                isDigit = true;              
            }
        }
        
        for (Character c: specs) {
            for (int i = 0; i < pw.length; i++) {
                if(pw[i] == c){
                    isSpecs = true;
                }
            }
        }
        
        if(isUpper==false){
            System.out.println("Invalid, Must contain 1 upper case");
        }
        if(isLower==false){
            System.out.println("Invalid, Must contain 1 lower case");
        }
        if(isDigit==false){
            System.out.println("Invalid, Must contain 1 number");
        }
        if(isSpecs==false){
            System.out.println("Invalid, Must contain 1 specs");
        }
        
        if(isUpper == false || isLower == false || isDigit == false || isSpecs == false){
            return INVALID;
        }
        
        return VALID;
    }

    /* this method checks if two passwords match each other */
    public boolean checkRetypePassword(char[] p1, char[] p2) {
        if (p1.length != p2.length) {
            System.out.println("password not matched, not same length");
            return INVALID;
        }
        for (int i = 0; i < p1.length; i++) {
            if (p1[i] != p2[i]) {
                System.out.println("password not matched");
                return INVALID;
            }
        }
        System.out.println("password matched");
        return VALID;
    }

//    /**/
//    /* main() to test the methods */
//    public static void main(String[] args) {
//        DataValidation dv = new DataValidation();
//        char[] pw = {'&','o','c','d','e','f','G','1'};
//        if(dv.checkPassword(pw)){
//            System.out.println("valid password");
//        }else{
//            System.out.println("invalid password");
//        }            
//    }
}
