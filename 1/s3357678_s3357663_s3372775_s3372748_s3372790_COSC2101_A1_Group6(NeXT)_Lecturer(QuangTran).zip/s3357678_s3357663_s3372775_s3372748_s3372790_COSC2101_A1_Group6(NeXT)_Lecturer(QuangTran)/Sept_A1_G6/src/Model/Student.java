package Model;

import java.util.ArrayList;

public class Student extends User {

    ArrayList<Classes> classes = new ArrayList<>();

    public Student(String ID, String firstName, String lastName, String dobDate, String dobMonth,
            String dobYear, String gender, String phoneNoCode, String phoneNo, String homeNoCode,
            String homeNo, String email, String address, String status, String description, String type,
            String currentdate, ArrayList<Classes> classes, String imageLink) {
        super(ID, firstName, lastName, dobDate, dobMonth, dobYear, gender, phoneNo, phoneNoCode,
                homeNo, homeNoCode, email, address, status, description, type, currentdate, imageLink);
        this.classes = classes;
    }

    public ArrayList<Classes> getClasses() {
        return classes;
    }

    public void setClasses(ArrayList<Classes> classes) {
        this.classes = classes;
    }
}
