package Model;

public class Teacher extends User {

    String[] skillList = new String[10];
    String[] classes = new String[10];

    public Teacher(String ID, String firstName, String lastName, Object dobDate, Object dobMonth,
            Object dobYear, Object gender, Object phoneNoCode, String phoneNo, Object homeNoCode,
            String homeNo, String email, String address, String status, String description, String type, 
            String currentdate, String[] skillList, String[] classes,String imageLink) {
        super(ID, firstName, lastName, dobDate, dobMonth, dobYear, gender, phoneNo, phoneNoCode,
                homeNo, homeNoCode, email, address, status, description, type, currentdate,imageLink);
        System.arraycopy(skillList, 0, this.skillList, 0, 9);
        System.arraycopy(classes, 0, this.classes, 0, 9);
    }

    public String[] getSkillList() {
        return skillList;
    }

    public void setSkillList(String[] skillList) {
        this.skillList = skillList;
    }

    public String[] getClasses() {
        return classes;
    }

    public void setClasses(String[] classes) {
        this.classes = classes;
    }
}
