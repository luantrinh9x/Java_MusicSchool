/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Model.Student;

/**
 *
 * @author minh
 */
public class StudentListItem {
    
    String id;
    String name;
    boolean selected = false;
    
    public StudentListItem(Manager std){
        id = std.getID();
        name = std.getLastName() + " " + std.getFirstName();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }    

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    
}
