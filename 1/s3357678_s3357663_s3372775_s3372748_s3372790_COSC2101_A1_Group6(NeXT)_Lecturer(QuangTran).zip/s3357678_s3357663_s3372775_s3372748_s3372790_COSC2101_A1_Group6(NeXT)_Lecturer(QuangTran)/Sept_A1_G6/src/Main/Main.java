package Main;

import Model.Classes;
import Model.Data;
import Model.Manager;
import View.LoginForm;
import java.awt.EventQueue;

public class Main {

    public static void main(String[] args) {

        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {

                Data da = new Data();
                
                Data.managerList = da.loadManagerData();
                Data.staffList = da.loadStaffData();
                Data.teacherList = da.loadTeacherData();
                Data.studentList = da.loadStudentData();
                Data.classList = da.loadClassData();
                
                for(Manager ma : Data.managerList){
                    System.out.println("First name: " + ma.getFirstName());
                    System.out.println("Email: " + ma.getEmail());
                    System.out.println(ma.getStatus());
                }
//                
//                for(Classes ma : Data.classList){
//                    if(ma.getClassType().equals("Guitar")){
//                        for(int i = 0; i < ma.getDays().length;i++){
//                            System.out.println("ID: " + ma.getId());
//                            System.out.println("days: " + ma.getDays()[i]);
//                            System.out.println("From: " + ma.getFroms()[i]);
//                            System.out.println("Tos: " + ma.getTos()[i]);
//                            System.out.println("");
//                        }
//                    }
//                }

                //Create the Login Form and start the program
                LoginForm login = LoginForm.getInstance();
                login.initialize();
            }
        });
    }
}
