package View;

import java.awt.*;
import javax.swing.*;

public class AssignmentForm extends JFrame {
    //declare

    private JPanel assignmentForm = new JPanel();
    private JButton close = new JButton("Close");
    private JLabel id = new JLabel("ID: ");
    private JLabel name = new JLabel("Name: ");
    private JLabel skill = new JLabel("Skill: ");
    private String[] data = {"A", "B", "C", "D", "E", "F", "G", "H"};
    private JList listSkill = new JList();
    private JScrollPane listScroller = new JScrollPane();

    public void initialize() {

        setLayout(null);

        //add data to scrollpane
        listSkill.setListData(data);
        listScroller.setViewportView(listSkill);

        //add properties to assingment form
        add(id);
        add(name);
        add(skill);
        add(listScroller);

        //set position
        id.setBounds(20, 20, 20, 20);
        name.setBounds(20, 60, 40, 20);
        skill.setBounds(400, 20, 40, 20);
        listScroller.setBounds(450, 20, 80, 60);

        //close button
        close.setBounds(490, 710, 70, 25);
        add(close);

        //ass form
        assignmentForm.setBackground(Color.gray);
        assignmentForm.setBounds(5, 100, 1010, 600);
        add(assignmentForm);
      

        //Set settings for the ManagerForm
        setTitle("Assignment Form");
        setSize(1024, 768);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        AssignmentForm m = new AssignmentForm();
        m.initialize();
    }
}
