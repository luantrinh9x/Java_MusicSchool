package View.ControlPanelFormUtilities;

import Controller.*;
import Model.*;
import View.ControlPanelForm;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.net.URL;
import java.util.*;
import java.util.logging.*;
import javax.imageio.ImageIO;
import javax.swing.*;

public class RightPanel extends JPanel implements Observer {

    private static RightPanel unique;
    //This font will be used for all components in this class
    private Font font = new Font("Comic sans ms", Font.ROMAN_BASELINE, 13);
    //Right panel's components
    private JScrollPane scroll = new JScrollPane();
    private JPanel scrollPanel = new JPanel();
    private JPanel[] infoRow = new JPanel[200];
    private JPanel[] checkBoxPanel = new JPanel[200];
    private JPanel[] typePanel = new JPanel[200];
    private JPanel[] infoPanel = new JPanel[200];
    private JPanel[] datePanel = new JPanel[200];
    private JPanel[] statusPanel = new JPanel[200];
    private boolean[] pressOrNot = new boolean[200];
    private DeleteButtonController deleteCon;
    private ActivateButtonController activateCon;
    private CopyClassController copyCon;

    public static RightPanel getInstance() {
        if (unique == null) {
            unique = new RightPanel();
        }
        return unique;
    }

    public void initialize(DeleteButtonController deleteCon, ActivateButtonController activateCon, CopyClassController copyCon) {
        this.deleteCon = deleteCon;
        this.activateCon = activateCon;
        this.copyCon = copyCon;
        //set right panel style
        setLayout(null);
        setBackground(Color.BLACK);
        setBounds(328, 5, 665, 595);
        //set scroll settings
        scroll.setBounds(-3, 0, 668, 595);
        scroll.setViewportView(scrollPanel);
        scroll.getVerticalScrollBar().setUnitIncrement(20);
        scrollPanel.setLayout(new GridLayout(0, 1, 0, 0));
        //Add ScrollPane to Control Panel
        add(scroll);
    }

    public void addStuffToScrollPanel(ArrayList<String> types, ArrayList<String> ids, ArrayList<String> names, ArrayList<String> infoOne,
            ArrayList<String> infoTwo, ArrayList<String> dates, ArrayList<Boolean> status) {
        //Remove everything start adding new stuff
        deleteCon.renew();
        activateCon.renew();
        copyCon.renew();
        scrollPanel.removeAll();
        infoRow = new JPanel[200];
        pressOrNot = new boolean[200];
        checkBoxPanel = new JPanel[200];
        typePanel = new JPanel[200];
        infoPanel = new JPanel[200];
        datePanel = new JPanel[200];
        statusPanel = new JPanel[200];
        //Add many rows of info
        for (int i = 0; i < 50; i++) {
            //Create an info row Panel
            infoRow[i] = new JPanel();
            infoRow[i].setLayout(null);
            infoRow[i].setPreferredSize(new Dimension(0, 120));
            if (i >= types.size()) {
                infoRow[i].setBackground(Color.WHITE);
                if (i == types.size()) {
                    infoRow[i].setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Color.BLACK));
                }
                scrollPanel.add(infoRow[i]);
            } else {
                //CheckBox panel
                checkBoxPanel[i] = newCheckBoxPanel(ids.get(i));
                checkBoxPanel[i].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.BLACK));
                //Type Panel
                typePanel[i] = newTypePanel(types.get(i));
                typePanel[i].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.BLACK));
                //Info Panel
                infoPanel[i] = newInfoPanel(ids.get(i), names.get(i), infoOne.get(i), infoTwo.get(i), types.get(i));
                infoPanel[i].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.BLACK));
                //Date Panel
                datePanel[i] = newDatePanel(dates.get(i));
                datePanel[i].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.BLACK));
                //Status Panel
                statusPanel[i] = newStatusPanel(status.get(i));
                statusPanel[i].setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, Color.BLACK));

                //Set listener for panels
                PanelsListener listener = new PanelsListener(i, ids.get(i));
                checkBoxPanel[i].addMouseListener(listener);
                typePanel[i].addMouseListener(listener);
                infoPanel[i].addMouseListener(listener);
                datePanel[i].addMouseListener(listener);
                statusPanel[i].addMouseListener(listener);
                //Add five panels to an manager row panel
                infoRow[i].add(checkBoxPanel[i]);
                infoRow[i].add(infoPanel[i]);
                infoRow[i].add(datePanel[i]);
                infoRow[i].add(typePanel[i]);
                infoRow[i].add(statusPanel[i]);
                //Add a manager rowpanel to ScrollPane
                scrollPanel.add(infoRow[i]);
            }
        }
        //Update this panel
        validate();
    }

    class PanelsListener implements MouseListener {

        private int index;
        private String id;

        public PanelsListener(int i, String id) {
            this.index = i;
            this.id = id;
        }

        @Override
        public void mouseClicked(MouseEvent me) {
            int reWhitePosition = -1;
            for (int i = 0; i < 50; i++) {
                if (pressOrNot[i] == true) {
                    reWhitePosition = i;
                }
            }
            if (pressOrNot[index] == false) {
                pressOrNot[index] = true;
                Color color = new Color(255, 170, 50);
                checkBoxPanel[index].setBackground(color);
                typePanel[index].setBackground(color);
                infoPanel[index].setBackground(color);
                datePanel[index].setBackground(color);
                statusPanel[index].setBackground(color);
                //Change left panel
                String url = "C:\\Users\\Naga\\Desktop\\Riven.png";
                char charID = id.charAt(0);
                switch (charID) {
                    case 'M':
                        for (Manager ma : Data.managerList) {

                            if (id.equals(ma.getID())) {
                                String day = (String) ma.getDobDate();
                                String mon = (String) ma.getDobMonth();
                                String yr = (String) ma.getDobYear();
                                String dat = day + "/" + mon + "/" + yr;
                                String gender = (String) ma.getGender();
                                LeftPanel.getInstance().setAllPeopleLabels(ma.getID(), dat, ma.getFirstName(), ma.getLastName(),
                                        gender, ma.getPhoneNo(), ma.getEmail(), ma.getAddress(), ma.getStatus(), ma.getUserType(), ma.getPhotoLink());
                            }
                        }
                    case 'V':
                        for (Teacher te : Data.teacherList) {

                            if (id.equals(te.getID())) {
                                String day = (String) te.getDobDate();
                                String mon = (String) te.getDobMonth();
                                String yr = (String) te.getDobYear();
                                String dat = day + "/" + mon + "/" + yr;
                                String gender = (String) te.getGender();
                                LeftPanel.getInstance().setAllPeopleLabels(te.getID(), dat, te.getFirstName(), te.getLastName(),
                                        gender, te.getPhoneNo(), te.getEmail(), te.getAddress(), te.getStatus(), te.getUserType(), te.getPhotoLink());
                            }
                        }
                    case 'T':
                        for (Staff st : Data.staffList) {

                            if (id.equals(st.getID())) {
                                String day = (String) st.getDobDate();
                                String mon = (String) st.getDobMonth();
                                String yr = (String) st.getDobYear();
                                String dat = day + "/" + mon + "/" + yr;
                                String gender = (String) st.getGender();
                                LeftPanel.getInstance().setAllPeopleLabels(st.getID(), dat, st.getFirstName(), st.getLastName(),
                                        gender, st.getPhoneNo(), st.getEmail(), st.getAddress(), st.getStatus(), st.getUserType(), st.getPhotoLink());
                            }
                        }
                    case 'S':
                        for (Student st : Data.studentList) {

                            if (id.equals(st.getID())) {
                                String day = (String) st.getDobDate();
                                String mon = (String) st.getDobMonth();
                                String yr = (String) st.getDobYear();
                                String dat = day + "/" + mon + "/" + yr;
                                String gender = (String) st.getGender();
                                LeftPanel.getInstance().setAllPeopleLabels(st.getID(), dat, st.getFirstName(), st.getLastName(),
                                        gender, st.getPhoneNo(), st.getEmail(), st.getAddress(), st.getStatus(), st.getUserType(), st.getPhotoLink());
                            }
                        }
                    case 'C':
                        for (Classes st : Data.classList) {

                            if (id.equals(st.getId())) {
                                LeftPanel.getInstance().setAllClassLabels(st.getId(), st.getClassCode() , st.getClassType(), st.getClassName(),
                                        "",st.getStartDate(),st.getEndDate(),"","",st.getClassType(),"","");
                            }
                        }
                    default:
                }

                if (reWhitePosition >= 0) {
                    pressOrNot[reWhitePosition] = false;
                    checkBoxPanel[reWhitePosition].setBackground(Color.WHITE);
                    typePanel[reWhitePosition].setBackground(Color.WHITE);
                    infoPanel[reWhitePosition].setBackground(Color.WHITE);
                    datePanel[reWhitePosition].setBackground(Color.WHITE);
                    statusPanel[reWhitePosition].setBackground(Color.WHITE);
                }
                copyCon.setId(id);
            } else {
                pressOrNot[index] = false;
                checkBoxPanel[index].setBackground(Color.WHITE);
                typePanel[index].setBackground(Color.WHITE);
                infoPanel[index].setBackground(Color.WHITE);
                datePanel[index].setBackground(Color.WHITE);
                statusPanel[index].setBackground(Color.WHITE);
            }
        }

        @Override
        public void mousePressed(MouseEvent me) {
        }

        @Override
        public void mouseReleased(MouseEvent me) {
        }

        @Override
        public void mouseEntered(MouseEvent me) {
        }

        @Override
        public void mouseExited(MouseEvent me) {
        }
    }

    public JPanel newCheckBoxPanel(String id) {
        JPanel checkBoxPanel = new JPanel();
        checkBoxPanel.setLayout(null);
        checkBoxPanel.setBounds(0, 0, 40, 120);
        checkBoxPanel.setBackground(Color.WHITE);
        //Create a small check box and add it to CheckBox panel
        JCheckBox checkBox = new JCheckBox();
        checkBox.setBounds(10, 50, 20, 20);
        checkBox.addItemListener(new CheckBoxListener(id));
        checkBoxPanel.add(checkBox);
        return checkBoxPanel;
    }

    class CheckBoxListener implements ItemListener {

        private String id;

        public CheckBoxListener(String id) {
            this.id = id;
        }

        public void itemStateChanged(ItemEvent e) {
            //If checked, return the id that this listener is holding
            //the problem is what if many checkboxes are checked at the same time
            //And if unchecked, how can it remove the id that it has passed to the delete button
            if (e.getStateChange() == ItemEvent.SELECTED) {
                deleteCon.setDeleteData(this.id);
                deleteCon.printOut();
                activateCon.setDeleteData(this.id);
                activateCon.printOut();
            }
            if (e.getStateChange() == ItemEvent.DESELECTED) {
                deleteCon.removeDeleteData(this.id);
                deleteCon.printOut();
                activateCon.removeDeleteData(this.id);
                activateCon.printOut();
            }
        }
    }

    public JPanel newTypePanel(String type) {
        JPanel typePanel = new JPanel();
        typePanel.setBounds(40, 0, 90, 120);
        typePanel.setLayout(null);
        typePanel.setBackground(Color.WHITE);
        //picture
        BufferedImage typeImage;
        JLabel picLabel = new JLabel();
        if (type.equals("Class")) {
            URL url = RightPanel.class.getResource("/Images/Class.png");
            try {
                typeImage = ImageIO.read(url);
                picLabel = new JLabel(new ImageIcon(typeImage));
                picLabel.setBounds(3, 5, 80, 70);
            } catch (IOException ex) {
                Logger.getLogger(ControlPanelForm.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            URL url = RightPanel.class.getResource("/Images/Stick.png");
            try {
                typeImage = ImageIO.read(url);
                picLabel = new JLabel(new ImageIcon(typeImage));
                picLabel.setBounds(25, 5, 50, 70);
            } catch (IOException ex) {
                Logger.getLogger(ControlPanelForm.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        picLabel.setOpaque(false);
        typePanel.add(picLabel);
        //Label
        JLabel typeLabel = new JLabel(type);
        typeLabel.setFont(font);
        if (type.equals("Staff") || type.equals("Class")) {
            typeLabel.setBounds(28, 90, 80, 20);
        } else {
            typeLabel.setBounds(20, 90, 80, 20);
        }
        typePanel.add(typeLabel);
        return typePanel;
    }

    public JPanel newInfoPanel(String id, String name, String infoOne, String infoTwo, String type) {
        JPanel infoPanel = new JPanel();
        infoPanel.setBounds(130, 0, 368, 120);
        infoPanel.setLayout(null);
        infoPanel.setBackground(Color.WHITE);
        //Labels
        JLabel idLabel = new JLabel("ID: " + id);
        idLabel.setFont(font);
        idLabel.setBounds(16, 10, 200, 20);
        infoPanel.add(idLabel);
        if (type.equals("Class")) {
            //Class Name
            JLabel nameLabel = new JLabel("Class name: " + name);
            nameLabel.setFont(font);
            nameLabel.setBounds(16, 37, 300, 20);
            //Class Code
            JLabel classCodeLabel = new JLabel("Class code: " + infoOne);
            classCodeLabel.setFont(font);
            classCodeLabel.setBounds(16, 64, 400, 20);
            //Class type
            JLabel classType = new JLabel("Class type: " + infoTwo);
            classType.setFont(font);
            classType.setBounds(16, 91, 300, 20);
            infoPanel.add(nameLabel);
            infoPanel.add(classCodeLabel);
            infoPanel.add(classType);
        } else {
            //Name
            JLabel nameLabel = new JLabel();
            if (type.equals("Student")) {
                nameLabel = new JLabel("Student name: " + name);
            } else if (type.equals("Teacher")) {
                nameLabel = new JLabel("Teacher name: " + name);
            } else if (type.equals("Manager")) {
                nameLabel = new JLabel("Manager name: " + name);
            } else if (type.equals("Staff")) {
                nameLabel = new JLabel("Staff name: " + name);
            }
            nameLabel.setFont(font);
            nameLabel.setBounds(16, 37, 300, 20);

            //Class 
            JLabel email = new JLabel("Email: " + infoTwo);;
            if (!infoOne.equals("")) {
                JLabel classLabel = new JLabel("Class: " + infoOne);
                classLabel.setFont(font);
                classLabel.setBounds(16, 64, 400, 20);
                infoPanel.add(classLabel);
                //Emails
                email.setBounds(16, 91, 300, 20);
            } else {
                //emails
                email.setBounds(16, 64, 300, 20);
            }
            email.setFont(font);
            infoPanel.add(email);
            infoPanel.add(nameLabel);
        }
        return infoPanel;
    }

    public JPanel newDatePanel(String date) {
        JPanel datePanel = new JPanel();
        datePanel.setBounds(498, 0, 90, 120);
        datePanel.setLayout(null);
        datePanel.setBackground(Color.WHITE);
        //Label
        JLabel dateLabel = new JLabel(date);
        dateLabel.setFont(font);
        dateLabel.setBounds(9, 45, 100, 30);
        datePanel.add(dateLabel);
        return datePanel;
    }

    public JPanel newStatusPanel(boolean status) {
        JPanel statusPanel = new JPanel();
        statusPanel.setBounds(587, 0, 60, 120);
        statusPanel.setLayout(null);
        statusPanel.setBackground(Color.WHITE);
        //picture
        BufferedImage statusImage;
        JLabel picLabel = new JLabel();
        if (status == true) {
            URL url = RightPanel.class.getResource("/Images/Green.png");
            try {
                statusImage = ImageIO.read(url);
                picLabel = new JLabel(new ImageIcon(statusImage));
            } catch (IOException ex) {
                Logger.getLogger(ControlPanelForm.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            URL url = RightPanel.class.getResource("/Images/Red.png");
            try {
                statusImage = ImageIO.read(url);
                picLabel = new JLabel(new ImageIcon(statusImage));
            } catch (IOException ex) {
                Logger.getLogger(ControlPanelForm.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        picLabel.setBounds(9, 35, 43, 43);
        picLabel.setOpaque(false);
        statusPanel.add(picLabel);
        return statusPanel;
    }

    @Override
    public void update(Observable o, Object arg) {
    }
}
