package View.ControlPanelFormUtilities;

import Model.Data;
import Model.Student;
import View.StudentTimeTable;
import View.TeacherTimeTable;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URL;
import java.util.*;
import javax.imageio.*;
import javax.swing.*;

public class LeftPanel extends JPanel implements Observer {

    private static LeftPanel unique;
    //This font will be used for all components in this class
    private Font font = new Font("Comic sans ms", Font.ROMAN_BASELINE, 13);
    private Font fontBold = new Font("Comic sans ms", Font.BOLD, 13);
    //Left panel's components
    private JPanel photoLine = new JPanel();
    private JLabel photo = new JLabel();
    private BufferedImage myPhoto;
    private JLabel id = new JLabel("ID: ");
    private JLabel dob = new JLabel("Date of Birth: ");
    private JLabel firstName = new JLabel("First name: ");
    private JLabel lastName = new JLabel("Last Name: ");
    private JLabel gender = new JLabel("Gender: ");
    private JLabel phoneNumber = new JLabel("Phone Number: ");
    private JLabel email = new JLabel("Email: ");
    private JLabel address = new JLabel("Address: ");
    private JLabel status = new JLabel("Status: ");
    private JLabel room = new JLabel("");
    private JButton editButton = new JButton("Edit");
    private JButton assignEnrolButton = new JButton("Assign/Enroll");
    private JButton viewSmallTimeTableButton = new JButton("View TimeTable");
    //Listeners for time tables and other buttons
    private EditButtonListener editListener = new EditButtonListener();
    private AssignButtonListener assignListener = new AssignButtonListener();
    private StudentTableListerner studentListener = new StudentTableListerner();
    private TeacherTableListerner teacherListener = new TeacherTableListerner();
    //Left Panel Output Components
    private JLabel idO = new JLabel();
    private JLabel dobO = new JLabel();
    private JLabel firstNameO = new JLabel();
    private JLabel lastNameO = new JLabel();
    private JLabel genderO = new JLabel();
    private JLabel phoneNumberO = new JLabel();
    private JLabel emailO = new JLabel();
    private JLabel addressO = new JLabel();
    private JLabel statusO = new JLabel();
    private JLabel roomO = new JLabel();

    public static LeftPanel getInstance() {
        if (unique == null) {
            unique = new LeftPanel();
        }
        return unique;
    }

    public void initialize() {
        //Set font for all components
        id.setFont(fontBold);
        dob.setFont(fontBold);
        firstName.setFont(fontBold);
        lastName.setFont(fontBold);
        gender.setFont(fontBold);
        phoneNumber.setFont(fontBold);
        email.setFont(fontBold);
        address.setFont(fontBold);
        status.setFont(fontBold);
        room.setFont(fontBold);

        editButton.setFont(font);
        assignEnrolButton.setFont(font);
        viewSmallTimeTableButton.setFont(font);
        idO.setFont(font);
        dobO.setFont(font);
        firstNameO.setFont(font);
        lastNameO.setFont(font);
        genderO.setFont(font);
        phoneNumberO.setFont(font);
        emailO.setFont(font);
        addressO.setFont(font);
        statusO.setFont(font);
        roomO.setFont(font);
        //Make Left Panel style
        setLayout(null);
        setBackground(new Color(204, 255, 230));
        setBounds(1, 7, 325, 590);
        //Make photo
        URL url = LeftPanel.class.getResource("/Images/Student.png");
        try {
            myPhoto = ImageIO.read(url);
            photo = new JLabel(new ImageIcon(myPhoto));
        } catch (IOException e) {
            System.out.println("Image not loading");
        }
        photoLine.removeAll();
        photoLine.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        photoLine.setLayout(new GridLayout(1, 1));
        photoLine.add(photo);
        //Set bound for photo
        photoLine.setBounds(72, 10, 180, 160);
        //Add to left panel
        add(id);
        add(dob);
        add(firstName);
        add(lastName);
        add(gender);
        add(phoneNumber);
        add(email);
        add(address);
        add(status);
        add(room);
        add(photoLine);
        add(editButton);
        add(assignEnrolButton);
        add(idO);
        add(dobO);
        add(firstNameO);
        add(lastNameO);
        add(genderO);
        add(phoneNumberO);
        add(emailO);
        add(addressO);
        add(statusO);
        add(roomO);
        // set listeners for 'Edit' and 'Assign'
        editButton.addActionListener(editListener);
        assignEnrolButton.addActionListener(assignListener);
    }

    //Set new values for labels  and assign ActionListener for buttons
    public void setAllPeopleLabels(String id, String dob, String firstName, String lastName, String gender,
            String phoneNumber, String email, String address, String status, String type, String url) {
        //Load Image
        try {
            myPhoto = ImageIO.read(new File(url));
            photo = new JLabel(new ImageIcon(myPhoto));
        } catch (IOException e) {
            System.out.println("Image not loading");
        }
        photoLine.removeAll();
        photoLine.add(photo);
        //set labels
        this.id.setText("ID: ");
        this.dob.setText("Date of Birth: ");
        this.firstName.setText("First name: ");
        this.lastName.setText("Last Name: ");
        this.gender.setText("Gender: ");
        this.phoneNumber.setText("Phone Number: ");
        this.email.setText("Email: ");
        this.address.setText("Address: ");
        this.status.setText("Status: ");
        this.room.setText("");
        //Set new texts info
        idO.setText(id);
        dobO.setText(dob);
        firstNameO.setText(firstName);
        lastNameO.setText(lastName);
        genderO.setText(gender);
        phoneNumberO.setText(phoneNumber);
        emailO.setText(email);
        addressO.setText(address);
        statusO.setText(status);
        roomO.setText("");
        //set bounds
        this.id.setBounds(10, 180, 30, 20);
        this.dob.setBounds(10, 215, 100, 20);
        this.firstName.setBounds(10, 250, 100, 20);
        this.lastName.setBounds(10, 285, 100, 20);
        this.gender.setBounds(10, 320, 100, 20);
        this.phoneNumber.setBounds(10, 355, 120, 20);
        this.email.setBounds(10, 390, 100, 20);
        this.address.setBounds(10, 425, 100, 20);
        this.status.setBounds(10, 460, 420, 20);

        idO.setBounds(40, 180, 200, 20);
        dobO.setBounds(110, 215, 200, 20);
        firstNameO.setBounds(90, 250, 200, 20);
        lastNameO.setBounds(90, 285, 200, 20);
        genderO.setBounds(70, 320, 200, 20);
        phoneNumberO.setBounds(115, 355, 200, 20);
        emailO.setBounds(55, 390, 390, 20);
        addressO.setBounds(75, 425, 200, 20);
        statusO.setBounds(70, 460, 200, 20);
        //Update edit listener
        editListener.setId(id);
        //Listeners' conditions
        if (type.equals("Student")) {
            //remover old listeners
            viewSmallTimeTableButton.removeActionListener(studentListener);
            viewSmallTimeTableButton.removeActionListener(teacherListener);
            //add new listener
            viewSmallTimeTableButton.addActionListener(studentListener);
            //set bounds
            editButton.setBounds(10, 550, 70, 30);
            assignEnrolButton.setBounds(80, 550, 110, 30);
            viewSmallTimeTableButton.setBounds(190, 550, 130, 30);
            add(editButton);
            add(assignEnrolButton);
            add(viewSmallTimeTableButton);


        } else if (type.equals("Teacher")) {
            //remove old listeners
            viewSmallTimeTableButton.removeActionListener(studentListener);
            viewSmallTimeTableButton.removeActionListener(teacherListener);
            //add new listener
            viewSmallTimeTableButton.addActionListener(teacherListener);
            //set bounds
            editButton.setBounds(10, 550, 70, 30);
            assignEnrolButton.setBounds(80, 550, 110, 30);
            viewSmallTimeTableButton.setBounds(190, 550, 130, 30);
            add(editButton);
            add(assignEnrolButton);
            add(viewSmallTimeTableButton);
        } else if (type.equals("Staff")) {
            //Set bounds for buttons
            editButton.setBounds(125, 550, 70, 30);
            add(editButton);
            remove(assignEnrolButton);
            remove(viewSmallTimeTableButton);
        } else if (type.equals("Manager")) {
            //Set bounds for buttons
            editButton.setBounds(125, 550, 70, 30);
            add(editButton);
            remove(assignEnrolButton);
            remove(viewSmallTimeTableButton);
        }
        //Update the left panel with new information
        validate();
    }

    public void setAllClassLabels(String id, String dob, String firstName, String lastName, String gender,
            String phoneNumber, String email, String address, String status, String type, String room, String url) {
        //Load Image
        try {
            myPhoto = ImageIO.read(new File(url));
            photo = new JLabel(new ImageIcon(myPhoto));
        } catch (IOException e) {
            System.out.println("Image not loading");
        }
        photoLine.removeAll();
        photoLine.add(photo);
        //Set labels
        this.id.setText("ID: ");
        this.dob.setText("Class Code: ");
        this.firstName.setText("Class type: ");
        this.lastName.setText("Class Name: ");
        this.gender.setText("Tuition Fee: ");
        this.phoneNumber.setText("Start Date: ");
        this.email.setText("End Date: ");
        this.address.setText("Start Time: ");
        this.status.setText("End Time: ");
        this.room.setText("Room: ");
        idO.setText(id);
        dobO.setText(dob);
        firstNameO.setText(firstName);
        lastNameO.setText(lastName);
        genderO.setText(gender);
        phoneNumberO.setText(phoneNumber);
        emailO.setText(email);
        addressO.setText(address);
        statusO.setText(status);
        roomO.setText(room);

        this.id.setBounds(10, 180, 30, 20);
        this.dob.setBounds(10, 215, 100, 20);
        this.firstName.setBounds(10, 250, 100, 20);
        this.lastName.setBounds(10, 285, 100, 20);
        this.gender.setBounds(10, 320, 100, 20);
        this.phoneNumber.setBounds(10, 355, 120, 20);
        this.email.setBounds(10, 390, 100, 20);
        this.address.setBounds(10, 425, 100, 20);
        this.status.setBounds(10, 460, 420, 20);
        this.room.setBounds(10, 495, 420, 20);

        idO.setBounds(40, 180, 200, 20);
        dobO.setBounds(90, 215, 200, 20);
        firstNameO.setBounds(90, 250, 200, 20);
        lastNameO.setBounds(100, 285, 200, 20);
        genderO.setBounds(100, 320, 200, 20);
        phoneNumberO.setBounds(95, 355, 200, 20);
        emailO.setBounds(85, 390, 390, 20);
        addressO.setBounds(95, 425, 200, 20);
        statusO.setBounds(90, 460, 200, 20);
        roomO.setBounds(60, 495, 200, 20);
        //Set bounds for buttons
        editButton.setBounds(125, 550, 70, 30);
        //Update edit listener
        editListener.setId(id);
        add(editButton);
        remove(assignEnrolButton);
        remove(viewSmallTimeTableButton);
        //Update the left panel with new information
        validate();
    }

    public void setAllLabelsEmpty() {
        //Make photo
        URL url = LeftPanel.class.getResource("/Images/Student.png");
        try {
            myPhoto = ImageIO.read(url);
            photo = new JLabel(new ImageIcon(myPhoto));
        } catch (IOException e) {
            System.out.println("Image not loading");
        }
        photoLine.removeAll();
        photoLine.add(photo);
        //Set labels
        this.id.setText("");
        this.dob.setText("");
        this.firstName.setText("");
        this.lastName.setText("");
        this.gender.setText("");
        this.phoneNumber.setText("");
        this.email.setText("");
        this.address.setText("");
        this.status.setText("");
        this.room.setText("");
        idO.setText("");
        dobO.setText("");
        firstNameO.setText("");
        lastNameO.setText("");
        genderO.setText("");
        phoneNumberO.setText("");
        emailO.setText("");
        addressO.setText("");
        statusO.setText("");
        roomO.setText("");
        //Set bounds for buttons
        remove(editButton);
        remove(assignEnrolButton);
        remove(viewSmallTimeTableButton);
        //Update the left panel with new information
        validate();
    }

    class EditButtonListener implements ActionListener {

        private String id;

        public void setId(String id) {
            this.id = id;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println(id);
            Data data = new Data();
            data.Edit(id);
        }
    }

    class AssignButtonListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("From Assign Button");
        }
    }

    class StudentTableListerner extends Observable implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String id = idO.getText();
            Student tempstu = null;
            boolean active = false;

            for (Student stu : Data.studentList) {
                if (stu.getID().equals(id)) {
                    tempstu = stu;
                    active = true;
                    break;
                }
            }

            if (active) {
                StudentTimeTable.setUnique(null);
                StudentTimeTable studentTime = StudentTimeTable.getInstance();

                studentTime.initialize();
//                studentTime.getTimeTable().getTimeModel().resetChosenClass();
                
                for (int i = 0; i < tempstu.getClasses().size(); i++) {
                    for (int j = 0; j < tempstu.getClasses().get(i).getDays().length; j++) {
                        System.out.println("Classname " + tempstu.getClasses().get(i).getClassName());
                        System.out.println("Day " + tempstu.getClasses().get(i).getDays()[j]);
                        System.out.println("Code " + tempstu.getClasses().get(i).getClassCode());
                        System.out.println("Type " + tempstu.getClasses().get(i).getClassType());
                        System.out.println("From " + tempstu.getClasses().get(i).getFroms()[j]);
                        System.out.println("To " + tempstu.getClasses().get(i).getTos()[j]);
                        System.out.println("");
                        
                        String from = tempstu.getClasses().get(i).getFroms()[j];
                        String tos = tempstu.getClasses().get(i).getTos()[j];

                        if (from.length() == 4) {
                            from = "0" + from;
                        }

                        if (tos.length() == 4) {
                            tos = "0" + tos;
                        }
                        
                        studentTime.getTimeTable().getTimeController().onCreateClass(tempstu.getClasses().get(i).getId(),
                                tempstu.getClasses().get(i).getDays()[j],
                                from,
                                tos,
                                tempstu.getClasses().get(i).getClassName(),
                                tempstu.getClasses().get(i).getId(),
                                tempstu.getClasses().get(i).getClassCode(),
                                tempstu.getClasses().get(i).getRooms()[j],
                                "");
                    }

                }
//                studentTime.getTimeTable().getTimeController().onCreateClass("1",
//                                "Mon",
//                                "09:00",
//                                "10:30",
//                                "sample name",
//                                "1",
//                                "SAM123",
//                                "1",
//                                "");
                
//                studentTime.getTimeTable().getTimeModel().change();
            }

        }
    }

    class TeacherTableListerner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            TeacherTimeTable teacherTime = TeacherTimeTable.getInstance();
            teacherTime.initialize();
        }
    }

    @Override
    public void update(Observable o, Object arg) {
    }
}
