package View;

import Controller.ClassFormController;
import com.toedter.calendar.JCalendar;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import Model.Data;
import com.toedter.calendar.JDateChooser;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Date;

public class ClassForm extends JFrame {

    // Delare properties
    private JPanel labelPane = new JPanel();
    private JLayeredPane valuePane1 = new JLayeredPane();
    private JPanel picPane = new JPanel();
    private JPanel valuePane2 = new JPanel();
    private JPanel textAreaPane = new JPanel();
    private JPanel buttonPane = new JPanel();
    private JPanel datePickerPane = new JPanel();
    private JCalendar datePicker = new JCalendar();
    private JLabel id = new JLabel("Class ID");
    private JLabel name = new JLabel("Class name");
    private JLabel code = new JLabel("Class code");
    private JLabel start = new JLabel("Start date");
    private JLabel end = new JLabel("End date");
    private JLabel type = new JLabel("Class Type");
    private JLabel details = new JLabel("Date/Time");
    private JLabel desc = new JLabel("Description");
    private JLabel from;
    private JLabel to;
    private JLabel at;
    private JLabel studentEnrolled = new JLabel("Student Enrolled");
    private JLabel idText = new JLabel();
    private JTextField nameText = new JTextField();
    private JTextField codeText = new JTextField();
    private JComboBox typeCB = new JComboBox();
    private JComboBox fromCB = new JComboBox();
    private JComboBox toCB = new JComboBox();
    private JComboBox atCB = new JComboBox();
    private JComboBox monStartTime = new JComboBox();
    private JComboBox tueStartTime = new JComboBox();
    private JComboBox wedStartTime = new JComboBox();
    private JComboBox thuStartTime = new JComboBox();
    private JComboBox friStartTime = new JComboBox();
    private JComboBox satStartTime = new JComboBox();
    private JComboBox monEndTime = new JComboBox();
    private JComboBox tueEndTime = new JComboBox();
    private JComboBox wedEndTime = new JComboBox();
    private JComboBox thuEndTime = new JComboBox();
    private JComboBox friEndTime = new JComboBox();
    private JComboBox satEndTime = new JComboBox();
    private JComboBox monRoom = new JComboBox();
    private JComboBox tueRoom = new JComboBox();
    private JComboBox wedRoom = new JComboBox();
    private JComboBox thuRoom = new JComboBox();
    private JComboBox friRoom = new JComboBox();
    private JComboBox satRoom = new JComboBox();
    private JCheckBox mon = new JCheckBox("Mon");
    private JCheckBox tue = new JCheckBox("Tue");
    private JCheckBox wed = new JCheckBox("Wed");
    private JCheckBox thu = new JCheckBox("Thu");
    private JCheckBox fri = new JCheckBox("Fri");
    private JCheckBox sat = new JCheckBox("Sat");
    private JTextArea descA = new JTextArea("Class description...");
    private JButton addStudent = new JButton("Add Student");
    private JButton assignTeacher = new JButton("Assign Teacher");
    private JButton done = new JButton("Done");
    private JButton cancel = new JButton("Cancel");
    private JScrollPane scroll = new JScrollPane();
    private String[] student = {"gekk", "gekk", "gekk", "gekk", "gekk", "gekk", "gekk", "gekk", "gekk", "gekk", "gekk"};
    private JList studentList = new JList(student);
    private String userType = "Class";
    private static ClassForm unique;
    private ClassFormController classCon = new ClassFormController(this);
    JDateChooser dateChooser1 = new JDateChooser();
    JDateChooser dateChooser2 = new JDateChooser();
    private String startDate;
    private String endDate;

    public static ClassForm getInstance() {
        if (unique == null) {
            unique = new ClassForm();
        }
        return unique;
    }

    public void initialize() {

        //Label settings
        id.setBounds(10, 10, 50, 20);
        name.setBounds(10, 50, 100, 20);
        code.setBounds(10, 90, 100, 20);
        start.setBounds(10, 130, 100, 20);
        end.setBounds(10, 170, 100, 20);
        type.setBounds(10, 210, 100, 20);
        details.setBounds(10, 250, 100, 20);
        desc.setBounds(10, 480, 100, 20);
        studentEnrolled.setBounds(330, 10, 100, 20);
        // create from labels, set positions and sizes
        from = new JLabel("from");
        from.setBounds(90, 10, 25, 20);
        valuePane2.add(from);
        from = new JLabel("from");
        from.setBounds(90, 50, 25, 20);
        valuePane2.add(from);
        from = new JLabel("from");
        from.setBounds(90, 90, 25, 20);
        valuePane2.add(from);
        from = new JLabel("from");
        from.setBounds(90, 130, 25, 20);
        valuePane2.add(from);
        from = new JLabel("from");
        from.setBounds(90, 170, 25, 20);
        valuePane2.add(from);
        from = new JLabel("from");
        from.setBounds(90, 210, 25, 20);
        valuePane2.add(from);
        // create to labels, set positions and sizes
        to = new JLabel("to");
        to.setBounds(230, 10, 15, 20);
        valuePane2.add(to);
        to = new JLabel("to");
        to.setBounds(230, 50, 15, 20);
        valuePane2.add(to);
        to = new JLabel("to");
        to.setBounds(230, 90, 15, 20);
        valuePane2.add(to);
        to = new JLabel("to");
        to.setBounds(230, 130, 15, 20);
        valuePane2.add(to);
        to = new JLabel("to");
        to.setBounds(230, 170, 15, 20);
        valuePane2.add(to);
        to = new JLabel("to");
        to.setBounds(230, 210, 15, 20);
        valuePane2.add(to);
        // create at labels, set positions and sizes
        at = new JLabel("at");
        at.setBounds(340, 10, 15, 20);
        valuePane2.add(at);
        at = new JLabel("at");
        at.setBounds(340, 50, 15, 20);
        valuePane2.add(at);
        at = new JLabel("at");
        at.setBounds(340, 90, 15, 20);
        valuePane2.add(at);
        at = new JLabel("at");
        at.setBounds(340, 130, 15, 20);
        valuePane2.add(at);
        at = new JLabel("at");
        at.setBounds(340, 170, 15, 20);
        valuePane2.add(at);
        at = new JLabel("at");
        at.setBounds(340, 210, 15, 20);
        valuePane2.add(at);

        // Checkbox settings
        mon.setBounds(10, 10, 50, 20);
        tue.setBounds(10, 50, 50, 20);
        wed.setBounds(10, 90, 60, 20);
        thu.setBounds(10, 130, 50, 20);
        fri.setBounds(10, 170, 50, 20);
        sat.setBounds(10, 210, 50, 20);

        //Textfield settings
        idText.setBounds(10, 10, 150, 25);
        nameText.setBounds(10, 50, 150, 25);
        codeText.setBounds(10, 90, 150, 25);

        //dateChooser settings
        dateChooser1.setBounds(10, 130, 150, 25);
        dateChooser2.setBounds(10, 170, 150, 25);
        dateChooser1.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                if ("date".equals(evt.getPropertyName())) {
                    System.out.println(evt.getPropertyName()
                            + ": " + (Date) evt.getNewValue());
//                    date = evt.getNewValue().toString();
                    startDate = String.format("%1$td-%1$tm-%1$tY", evt.getNewValue());
                    System.out.println(startDate);
                }
            }
        });

        dateChooser2.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                if ("date".equals(evt.getPropertyName())) {
                    System.out.println(evt.getPropertyName()
                            + ": " + (Date) evt.getNewValue());
//                    date = evt.getNewValue().toString();
                    endDate = String.format("%1$td-%1$tm-%1$tY", evt.getNewValue());
                    System.out.println(endDate);
                }
            }
        });

        //Combobox settings
        typeCB.setBounds(10, 210, 110, 25);
        typeCB.setMaximumRowCount(4);
        typeCB.addItem("Ballet");
        typeCB.addItem("Hiphop");
        typeCB.addItem("Guitar");
        typeCB.addItem("Organ");
        typeCB.addItem("Painting");
        typeCB.addItem("Photography");
        typeCB.addItem("Singing");
        typeCB.addItem("Piano");
        // method to set time for start time and end time combo boxes
        for (int i = 8; i <= 18; i++) { // add items for startTime and endTime
            int j = 1;
            String num = "";
            if (i == 8 || i == 9) {
                num = "0" + i;
            } else {
                num = i + "";
            }
            if (j % 2 != 0) {

                monStartTime.addItem(num + ":00");
                tueStartTime.addItem(num + ":00");
                wedStartTime.addItem(num + ":00");
                thuStartTime.addItem(num + ":00");
                friStartTime.addItem(num + ":00");
                satStartTime.addItem(num + ":00");
                monEndTime.addItem(num + ":00");
                tueEndTime.addItem(num + ":00");
                wedEndTime.addItem(num + ":00");
                thuEndTime.addItem(num + ":00");
                friEndTime.addItem(num + ":00");
                satEndTime.addItem(num + ":00");
                j++;
            }
            if (j % 2 == 0 && !num.equals("18")) {
                monStartTime.addItem(num + ":30");
                tueStartTime.addItem("" + num + ":30");
                wedStartTime.addItem("" + num + ":30");
                thuStartTime.addItem("" + num + ":30");
                friStartTime.addItem("" + num + ":30");
                satStartTime.addItem("" + num + ":30");
                monEndTime.addItem("" + num + ":30");
                tueEndTime.addItem("" + num + ":30");
                wedEndTime.addItem("" + num + ":30");
                thuEndTime.addItem("" + num + ":30");
                friEndTime.addItem("" + num + ":30");
                satEndTime.addItem("" + num + ":30");
                j++;
            }
        }

        //Add fixed room
        for (int i = 1; i <= 8; i++) {
            monRoom.addItem("" + i);
            tueRoom.addItem("" + i);
            wedRoom.addItem("" + i);
            thuRoom.addItem("" + i);
            friRoom.addItem("" + i);
            satRoom.addItem("" + i);
        }

        if (Data.classList.isEmpty()) {
            this.idText.setText("C1");
        } else {
            String temp = Data.classList.get(Data.classList.size() - 1).getId();
            int num = Integer.parseInt(temp.substring(1));
            num++;
            this.idText.setText("C" + num);
        }

        // method to set appropriate room for certain class type
                /*room also has to have a type: 1to1, 1tomany*/
        // set bounds for start and end time combo boxes
        monStartTime.setBounds(145, 8, 65, 25);
        tueStartTime.setBounds(145, 48, 65, 25);
        wedStartTime.setBounds(145, 88, 65, 25);
        thuStartTime.setBounds(145, 128, 65, 25);
        friStartTime.setBounds(145, 168, 65, 25);
        satStartTime.setBounds(145, 208, 65, 25);
        monEndTime.setBounds(260, 8, 65, 25);
        tueEndTime.setBounds(260, 48, 65, 25);
        wedEndTime.setBounds(260, 88, 65, 25);
        thuEndTime.setBounds(260, 128, 65, 25);
        friEndTime.setBounds(260, 168, 65, 25);
        satEndTime.setBounds(260, 208, 65, 25);
        // set bounds for room combo box
        monRoom.setBounds(370, 8, 80, 25);
        tueRoom.setBounds(370, 48, 80, 25);
        wedRoom.setBounds(370, 88, 80, 25);
        thuRoom.setBounds(370, 128, 80, 25);
        friRoom.setBounds(370, 168, 80, 25);
        satRoom.setBounds(370, 208, 80, 25);

        // Create an inner Listener class to display the date picker
        // when user clicks on sdField and edField
        class CalListener implements ItemListener {

            @Override
            public void itemStateChanged(ItemEvent e) {
                JToggleButton b = (JToggleButton) e.getSource();
                if (b.isSelected()) {
                    datePickerPane.setLayout(null);
                    datePickerPane.setBorder(BorderFactory.createLineBorder(Color.green));
                    datePicker.setBounds(0, 0, 290, 200);
                    datePicker.setMaxDayCharacters(1);
                    datePicker.setFont(new Font(Font.SERIF, Font.PLAIN, 8));
                    datePickerPane.add(datePicker);
                    datePickerPane.setBounds(160, 130, 500, 150);
                    ClassForm.getInstance().getScroll().setFocusable(false);
                    ClassForm.getInstance().getScroll().setEnabled(false);
//                    ClassForm.getInstance().getScroll().disable();
                    valuePane1.add(datePickerPane, 0);
//                    ClassForm.getInstance().setEnabled(false);

                } else {
                    valuePane1.remove(datePickerPane);
                    ClassForm.getInstance().getScroll().setFocusable(true);
                    ClassForm.getInstance().getScroll().setFocusable(true);
//                    ClassForm.getInstance().getScroll().enable();
//                    ClassForm.getInstance().getValuePane2().setEnabled(true);
//                    ClassForm.getInstance().setEnabled(true);
                    repaint();
                }
            }
        }

        //Text area settings
        descA.setBounds(0, 0, 450, 80);
        descA.setLineWrap(true);
        descA.setWrapStyleWord(true);


        // Panels settings
        labelPane.setBounds(0, 0, 80, 560);
//        labelPane.setBorder(BorderFactory.createLineBorder(Color.blue));
        valuePane1.setBounds(80, 0, 650, 350);
//        valuePane1.setBorder(BorderFactory.createLineBorder(Color.red));
        picPane.setBounds(500, 0, 300, 250);
//        picPane.setBorder(BorderFactory.createLineBorder(Color.green));
        valuePane2.setBounds(80, 240, 450, 240);
//        valuePane2.setBorder(BorderFactory.createLineBorder(Color.orange));
        textAreaPane.setBounds(80, 480, 450, 80);
//        textAreaPane.setBorder(BorderFactory.createLineBorder(Color.magenta));
        buttonPane.setBounds(0, 560, 530, 40);
//        buttonPane.setBorder(BorderFactory.createLineBorder(Color.BLACK));


        // Set panels layouts
        labelPane.setLayout(null);
        valuePane1.setLayout(null);
        picPane.setLayout(null);
        valuePane2.setLayout(null);
        textAreaPane.setLayout(null);
        buttonPane.setLayout(null);

        // Button settings
        addStudent.setBounds(5, 10, 120, 25);
        assignTeacher.setBounds(140, 10, 120, 25);
        done.setBounds(275, 10, 120, 25);
        cancel.setBounds(405, 10, 120, 25);

        // Scrollpane setting
        scroll.setBounds(300, 40, 150, 190);

        scroll.add(studentList);
        scroll.setViewportView(studentList);

        // Add labels to panels
        labelPane.add(id);
        labelPane.add(name);
        labelPane.add(code);
        labelPane.add(start);
        labelPane.add(end);
        labelPane.add(type);
        labelPane.add(details);
        labelPane.add(desc);
        valuePane1.add(studentEnrolled);

        // Add textfield to panels
        valuePane1.add(idText, 1);
        valuePane1.add(nameText, 1);
        valuePane1.add(codeText, 1);
        valuePane1.add(dateChooser1, 1);
        valuePane1.add(dateChooser2, 1);

        // Add checkbox to panel
        valuePane2.add(mon);
        valuePane2.add(tue);
        valuePane2.add(wed);
        valuePane2.add(thu);
        valuePane2.add(fri);
        valuePane2.add(sat);

        // Add combo box to panel
        valuePane1.add(typeCB, 1);
        valuePane2.add(monStartTime);
        valuePane2.add(tueStartTime);
        valuePane2.add(wedStartTime);
        valuePane2.add(thuStartTime);
        valuePane2.add(friStartTime);
        valuePane2.add(satStartTime);
        valuePane2.add(monEndTime);
        valuePane2.add(tueEndTime);
        valuePane2.add(wedEndTime);
        valuePane2.add(thuEndTime);
        valuePane2.add(friEndTime);
        valuePane2.add(satEndTime);
        valuePane2.add(monRoom);
        valuePane2.add(tueRoom);
        valuePane2.add(wedRoom);
        valuePane2.add(thuRoom);
        valuePane2.add(friRoom);
        valuePane2.add(satRoom);

        // Add text area to panel
        textAreaPane.add(descA);

        // Add buttons to panel
        buttonPane.add(addStudent);
        buttonPane.add(assignTeacher);
        buttonPane.add(done);
        done.addActionListener(classCon);
        buttonPane.add(cancel);
        cancel.addActionListener(classCon);
        
        // Add scroll to panel
        valuePane1.add(scroll, 2);

        // Add panels to frame
        add(labelPane);
        add(valuePane1);
//        add(picPane);
        add(valuePane2);
        add(textAreaPane);
        add(buttonPane);

        // Frame settings
        setTitle("Class Form");
        setLayout(null);
        setSize(540, 630);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setLocationRelativeTo(null);

        //Set look and feel
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            SwingUtilities.updateComponentTreeUI(this);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Can't change look and feel", "Invalid PLAF",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public JPanel getLabelPane() {
        return labelPane;
    }

    public void setLabelPane(JPanel labelPane) {
        this.labelPane = labelPane;
    }

    public JLayeredPane getValuePane1() {
        return valuePane1;
    }

    public void setValuePane1(JLayeredPane valuePane1) {
        this.valuePane1 = valuePane1;
    }

    public JPanel getPicPane() {
        return picPane;
    }

    public void setPicPane(JPanel picPane) {
        this.picPane = picPane;
    }

    public JPanel getValuePane2() {
        return valuePane2;
    }

    public void setValuePane2(JPanel valuePane2) {
        this.valuePane2 = valuePane2;
    }

    public JPanel getTextAreaPane() {
        return textAreaPane;
    }

    public void setTextAreaPane(JPanel textAreaPane) {
        this.textAreaPane = textAreaPane;
    }

    public JPanel getButtonPane() {
        return buttonPane;
    }

    public void setButtonPane(JPanel buttonPane) {
        this.buttonPane = buttonPane;
    }

    public JPanel getDatePickerPane() {
        return datePickerPane;
    }

    public void setDatePickerPane(JPanel datePickerPane) {
        this.datePickerPane = datePickerPane;
    }

    public JCalendar getDatePicker() {
        return datePicker;
    }

    public void setDatePicker(JCalendar datePicker) {
        this.datePicker = datePicker;
    }

    public JLabel getId() {
        return id;
    }

    public void setId(JLabel id) {
        this.id = id;
    }

    public void setName(JLabel name) {
        this.name = name;
    }

    public JLabel getCode() {
        return code;
    }

    public void setCode(JLabel code) {
        this.code = code;
    }

    public JLabel getStart() {
        return start;
    }

    public void setStart(JLabel start) {
        this.start = start;
    }

    public JLabel getEnd() {
        return end;
    }

    public void setEnd(JLabel end) {
        this.end = end;
    }

    public void setType(JLabel type) {
        this.type = type;
    }

    public JLabel getDetails() {
        return details;
    }

    public void setDetails(JLabel details) {
        this.details = details;
    }

    public JLabel getDesc() {
        return desc;
    }

    public void setDesc(JLabel desc) {
        this.desc = desc;
    }

    public JLabel getFrom() {
        return from;
    }

    public void setFrom(JLabel from) {
        this.from = from;
    }

    public JLabel getTo() {
        return to;
    }

    public void setTo(JLabel to) {
        this.to = to;
    }

    public JLabel getAt() {
        return at;
    }

    public void setAt(JLabel at) {
        this.at = at;
    }

    public JLabel getStudentEnrolled() {
        return studentEnrolled;
    }

    public void setStudentEnrolled(JLabel studentEnrolled) {
        this.studentEnrolled = studentEnrolled;
    }

    public JLabel getIdText() {
        return idText;
    }

    public void setIdText(JLabel idText) {
        this.idText = idText;
    }

    public JTextField getNameText() {
        return nameText;
    }

    public void setNameText(JTextField nameText) {
        this.nameText = nameText;
    }

    public JTextField getCodeText() {
        return codeText;
    }

    public void setCodeText(JTextField codeText) {
        this.codeText = codeText;
    }

    public JComboBox getTypeCB() {
        return typeCB;
    }

    public void setTypeCB(JComboBox typeCB) {
        this.typeCB = typeCB;
    }

    public JComboBox getFromCB() {
        return fromCB;
    }

    public void setFromCB(JComboBox fromCB) {
        this.fromCB = fromCB;
    }

    public JComboBox getToCB() {
        return toCB;
    }

    public void setToCB(JComboBox toCB) {
        this.toCB = toCB;
    }

    public JComboBox getAtCB() {
        return atCB;
    }

    public void setAtCB(JComboBox atCB) {
        this.atCB = atCB;
    }

    public JComboBox getMonStartTime() {
        return monStartTime;
    }

    public void setMonStartTime(JComboBox monStartTime) {
        this.monStartTime = monStartTime;
    }

    public JComboBox getTueStartTime() {
        return tueStartTime;
    }

    public void setTueStartTime(JComboBox tueStartTime) {
        this.tueStartTime = tueStartTime;
    }

    public JComboBox getWedStartTime() {
        return wedStartTime;
    }

    public void setWedStartTime(JComboBox wedStartTime) {
        this.wedStartTime = wedStartTime;
    }

    public JComboBox getThuStartTime() {
        return thuStartTime;
    }

    public void setThuStartTime(JComboBox thuStartTime) {
        this.thuStartTime = thuStartTime;
    }

    public JComboBox getFriStartTime() {
        return friStartTime;
    }

    public void setFriStartTime(JComboBox friStartTime) {
        this.friStartTime = friStartTime;
    }

    public JComboBox getSatStartTime() {
        return satStartTime;
    }

    public void setSatStartTime(JComboBox satStartTime) {
        this.satStartTime = satStartTime;
    }

    public JComboBox getMonEndTime() {
        return monEndTime;
    }

    public void setMonEndTime(JComboBox monEndTime) {
        this.monEndTime = monEndTime;
    }

    public JComboBox getTueEndTime() {
        return tueEndTime;
    }

    public void setTueEndTime(JComboBox tueEndTime) {
        this.tueEndTime = tueEndTime;
    }

    public JComboBox getWedEndTime() {
        return wedEndTime;
    }

    public void setWedEndTime(JComboBox wedEndTime) {
        this.wedEndTime = wedEndTime;
    }

    public JComboBox getThuEndTime() {
        return thuEndTime;
    }

    public void setThuEndTime(JComboBox thuEndTime) {
        this.thuEndTime = thuEndTime;
    }

    public JComboBox getFriEndTime() {
        return friEndTime;
    }

    public void setFriEndTime(JComboBox friEndTime) {
        this.friEndTime = friEndTime;
    }

    public JComboBox getSatEndTime() {
        return satEndTime;
    }

    public void setSatEndTime(JComboBox satEndTime) {
        this.satEndTime = satEndTime;
    }

    public JComboBox getMonRoom() {
        return monRoom;
    }

    public void setMonRoom(JComboBox monRoom) {
        this.monRoom = monRoom;
    }

    public JComboBox getTueRoom() {
        return tueRoom;
    }

    public void setTueRoom(JComboBox tueRoom) {
        this.tueRoom = tueRoom;
    }

    public JComboBox getWedRoom() {
        return wedRoom;
    }

    public void setWedRoom(JComboBox wedRoom) {
        this.wedRoom = wedRoom;
    }

    public JComboBox getThuRoom() {
        return thuRoom;
    }

    public void setThuRoom(JComboBox thuRoom) {
        this.thuRoom = thuRoom;
    }

    public JComboBox getFriRoom() {
        return friRoom;
    }

    public void setFriRoom(JComboBox friRoom) {
        this.friRoom = friRoom;
    }

    public JComboBox getSatRoom() {
        return satRoom;
    }

    public void setSatRoom(JComboBox satRoom) {
        this.satRoom = satRoom;
    }

    public JCheckBox getMon() {
        return mon;
    }

    public void setMon(JCheckBox mon) {
        this.mon = mon;
    }

    public JCheckBox getTue() {
        return tue;
    }

    public void setTue(JCheckBox tue) {
        this.tue = tue;
    }

    public JCheckBox getWed() {
        return wed;
    }

    public void setWed(JCheckBox wed) {
        this.wed = wed;
    }

    public JCheckBox getThu() {
        return thu;
    }

    public void setThu(JCheckBox thu) {
        this.thu = thu;
    }

    public JCheckBox getFri() {
        return fri;
    }

    public void setFri(JCheckBox fri) {
        this.fri = fri;
    }

    public JCheckBox getSat() {
        return sat;
    }

    public void setSat(JCheckBox sat) {
        this.sat = sat;
    }

    public JTextArea getDescA() {
        return descA;
    }

    public void setDescA(JTextArea descA) {
        this.descA = descA;
    }

    public JButton getAddStudent() {
        return addStudent;
    }

    public void setAddStudent(JButton addStudent) {
        this.addStudent = addStudent;
    }

    public JButton getAssignTeacher() {
        return assignTeacher;
    }

    public void setAssignTeacher(JButton assignTeacher) {
        this.assignTeacher = assignTeacher;
    }

    public JButton getDone() {
        return done;
    }

    public void setDone(JButton done) {
        this.done = done;
    }

    public JButton getCancel() {
        return cancel;
    }

    public void setCancel(JButton cancel) {
        this.cancel = cancel;
    }

    public JScrollPane getScroll() {
        return scroll;
    }

    public void setScroll(JScrollPane scroll) {
        this.scroll = scroll;
    }

    public String[] getStudent() {
        return student;
    }

    public void setStudent(String[] student) {
        this.student = student;
    }

    public JList getStudentList() {
        return studentList;
    }

    public void setStudentList(JList studentList) {
        this.studentList = studentList;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public static ClassForm getUnique() {
        return unique;
    }

    public static void setUnique(ClassForm unique) {
        ClassForm.unique = unique;
    }

    
    public static void main(String[] args) {
        ClassForm cf = new ClassForm();
        cf.initialize();
    }
}
