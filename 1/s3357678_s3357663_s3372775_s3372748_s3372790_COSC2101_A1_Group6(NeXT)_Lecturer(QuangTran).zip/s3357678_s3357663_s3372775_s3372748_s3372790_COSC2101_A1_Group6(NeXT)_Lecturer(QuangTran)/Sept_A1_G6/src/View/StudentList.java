/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Controller.StudentListController;
import Model.Data;
import Model.StudentListItem;
import java.awt.Color;
import java.awt.Font;
import java.awt.TextField;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

/**
 *
 * @author minh
 */
public class StudentList extends JFrame {

    private JPanel searchPanel = new JPanel();
    private JPanel studentPanel = new JPanel();
    private JPanel buttonPanel = new JPanel();
    private JButton search = new JButton("Search");
    private JButton enroll = new JButton("Enroll");
    private JButton cancel = new JButton("Cancel");
    private JList list;
    private JScrollPane scroll = new JScrollPane();
    private TextField searchField = new TextField();

    public void initialize() {

        Font font = new Font("Agency FB", Font.PLAIN, 14);

        StudentListItem[] items = new StudentListItem[Data.managerList.size()];
        for (int i = 0; i < Data.managerList.size(); i++) {
            items[i] = new StudentListItem(Data.managerList.get(i));
        }
        
//        items = Data.managerList.toArray(new StudentListItem[Data.managerList.size()]);
        
        list = new JList(items);
        list.setCellRenderer(new StudentListRenderer());
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.addMouseListener(new StudentListController());
        System.out.println(Data.managerList.size());
        System.out.println(items.length);
        System.out.println(items[0].getId());
        System.out.println(items[0].getName());
        System.out.println(items[1].getId());


        // buttons settings
        search.setBounds(220, 13, 70, 25);
        enroll.setBounds(50, 10, 80, 25);
        cancel.setBounds(170, 10, 80, 25);

        // searchField settings
        searchField.setBounds(10, 15, 200, 20);
        searchField.setFont(font);

        // searchPanel settings
        searchPanel.setLayout(null);
        searchPanel.setBounds(0, 0, 300, 50);
        searchPanel.setBorder(BorderFactory.createLineBorder(Color.MAGENTA));
        
        // buttonPanel settings
        buttonPanel.setLayout(null);
        buttonPanel.setBounds(0, 370, 300, 50);
        buttonPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        buttonPanel.add(enroll);
        buttonPanel.add(cancel);

        // add textField to panels
        searchPanel.add(searchField);

        // add button to searchPanel
        searchPanel.add(search);

        // studentPanel settings
        studentPanel.setLayout(null);
        studentPanel.setBounds(0, 50, 300, 320);
        studentPanel.setBorder(BorderFactory.createLineBorder(Color.red));

        // scroll settings
        scroll.setBounds(0, 0, 300, 320);

        // add list to scroll pane
        scroll.add(list);
        scroll.setViewportView(list);
        studentPanel.add(scroll);

        // add stuffs to frame
        add(searchPanel);
        add(studentPanel);
        add(buttonPanel);

        // frame settings
        setLayout(null);
        setResizable(false);
        setTitle("Student List");
        setSize(306, 450);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        try {
//            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
//            SwingUtilities.updateComponentTreeUI(this);
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(this, "Can't change look and feel", "Invalid PLAF",
//                    JOptionPane.ERROR_MESSAGE);
//        }
    }

    public static void main(String[] args) {
        StudentList sl = new StudentList();
        Data da = new Data();
        Data.managerList = da.loadManagerData();
        Data.staffList = da.loadStaffData();
        sl.initialize();

    }
}
