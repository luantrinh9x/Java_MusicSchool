package View;

import TimetableUtilities.Timetable;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TeacherTimeTable extends JFrame {

    private static TeacherTimeTable unique;
    private Timetable timeTable;
    private JPanel timeTablePanel = new JPanel(new GridLayout(1, 1));
    private JButton close = new JButton("Close");

    //Singeton
    public static TeacherTimeTable getInstance() {
        if (unique == null) {
            unique = new TeacherTimeTable();
        }
        return unique;
    }
    
    public void initialize() {
        setLayout(null);
        timeTable = new Timetable();
        timeTable.settings();
        //remove old time tables
        timeTablePanel.removeAll();
        //JFrame's settings
        timeTablePanel.setBounds(15, 20, 820, 600);
        timeTablePanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        timeTablePanel.add(timeTable);
        add(timeTablePanel);
        //set close button
        close.setBounds(400, 630, 80, 30);
        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(close);
        
        //Set settings for the ManagerForm
        setTitle("View Time Table Teacher");
        setSize(850, 700);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        TeacherTimeTable m = new TeacherTimeTable();
        m.initialize();
    }
}
