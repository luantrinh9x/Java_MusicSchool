package View;

import Controller.ManagerFormController;
import Model.Data;
import javax.swing.*;

public class ManagerForm extends UserForm {

    private static ManagerForm unique;
    private ManagerFormController managerCon = new ManagerFormController(this);
    private JLabel userL;
    private JLabel passL;
    private JLabel retypeL;
    private JTextField userR;
    private JPasswordField passR;
    private JPasswordField retypeR;

    public static ManagerForm getInstance() {
        if (unique == null) {
            unique = new ManagerForm();
        }
        return unique;
    }

    public void managerInitialize() {

        //Call super
        super.initialize();
        if (Data.managerList.isEmpty()) {
            this.idR.setText("M1");
        } else {
            String temp = Data.managerList.get(Data.managerList.size() - 1).getID();
            int num = Integer.parseInt(temp.substring(1));
            num++;
            this.idR.setText("M" + num);
        }

        //Create instance
        userL = new JLabel("Username: ");
        passL = new JLabel("Password: ");
        retypeL = new JLabel("Retype password: ");
        userR = new JTextField(30);
        passR = new JPasswordField(30);
        retypeR = new JPasswordField(30);

        //Settings
        this.setUserType("Manager");


        //Adding
        userForm.add(userL);
        userForm.add(passL);
        userForm.add(retypeL);
        userForm.add(userR);
        userForm.add(passR);
        userForm.add(retypeR);

        userL.setBounds(10, 420, 70, 25);
        passL.setBounds(10, 460, 70, 25);
        retypeL.setBounds(10, 500, 120, 25);
        userR.setBounds(110, 420, 170, 25);
        passR.setBounds(110, 460, 170, 25);
        retypeR.setBounds(110, 500, 170, 25);
        add.setBounds(120, 540, 80, 25);
        cancel.setBounds(210, 540, 80, 25);

        //Set listener
        cancel.addActionListener(managerCon);
        add.addActionListener(managerCon);
        browse.addActionListener(managerCon);

        //JFrame's settings 
        setSize(440, 610);
        setTitle("Add Manager Form");
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
    }

    public JLabel getUserL() {
        return userL;
    }

    public JLabel getPassL() {
        return passL;
    }

    public JLabel getRetypeL() {
        return retypeL;
    }

    public JTextField getUserName() {
        return userR;
    }

    public void setUserName(JTextField userR) {
        this.userR = userR;
    }

    public JPasswordField getTypingPassword() {
        return passR;
    }

    public void setTypingPassword(JPasswordField passR) {
        this.passR = passR;
    }

    public JPasswordField getRetypePassword() {
        return retypeR;
    }

    public void setRetypePassword(JPasswordField retypeR) {
        this.retypeR = retypeR;
    }

    public static void setUnique(ManagerForm unique) {
        ManagerForm.unique = unique;
    }
}
