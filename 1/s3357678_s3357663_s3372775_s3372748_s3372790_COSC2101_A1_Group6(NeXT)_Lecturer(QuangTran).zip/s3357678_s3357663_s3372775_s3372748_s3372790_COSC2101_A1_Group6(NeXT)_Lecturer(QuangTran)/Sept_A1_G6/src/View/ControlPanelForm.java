package View;

import Controller.*;
import Model.Data;
import Model.Manager;
import View.ControlPanelFormUtilities.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.*;
import javax.imageio.*;
import javax.swing.*;
import org.jdesktop.xswingx.PromptSupport;

public class ControlPanelForm extends JFrame implements Observer{

    private static ControlPanelForm unique;
    private ControlPanelFormController cpCon = new ControlPanelFormController();
    private DeleteButtonController deleteCon = new DeleteButtonController();
    private ActivateButtonController activateCon = new ActivateButtonController();
    private CopyClassController copyCon = new CopyClassController();
    private String identifyUser;
    
    //This font will be used for all components in this class
    private Font font = new Font("Comic sans ms", Font.ROMAN_BASELINE, 13);
    //declare menu bar
    private JMenuBar menuBar = new JMenuBar();
    //declare menu
    private JMenu file = new JMenu("File");
    private JMenu edit = new JMenu("Edit");
    private JMenu help = new JMenu("Help");
    //declare menu item
    private JMenuItem exit = new JMenuItem("    Exit");
    private JMenuItem logout = new JMenuItem("    Logout");
    private JMenuItem userGuide = new JMenuItem("    User Guide");
    //One mother Panel contains all sub panels
    private JPanel motherPanel = new JPanel();
    /*There are two sub panels in Mother Panel: 
     * Function panel (Location:Top)
     * Contents panel (Location:Bot)
     */
    private JPanel functionPanel = new JPanel();
    private JPanel contentsPanel = new JPanel();
    //In function panel, we have two other panels: buttons panel and search panel 
    private JPanel buttonsPanel = new JPanel();
    private JPanel searchPanel = new JPanel();
    //Buttons of buttons panel
    private JButton addButton = new JButton("Add");
    private JButton deleteButton = new JButton("Delete");
    private JButton activateButton = new JButton("Activate");
    private JButton timeTableButton = new JButton("TimeTable");

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public JButton getActivateButton() {
        return activateButton;
    }

    public JButton getCopyClass() {
        return copyClass;
    }
    private JButton copyClass = new JButton("Copy Class");
    //search utility of seacrch panel
    private String[] comboBoxContents;
    private JComboBox userType;
    private JTextField searchField = new JTextField();
    private JButton search = new JButton("Search");
    private BufferedImage myPicture;
    private JLabel picLabel;
    //content panel (Bottom) has two small panel: Left panel and Right panel
    private LeftPanel leftPanel;
    private RightPanel rightPanel;
    private Data dat = new Data();
    
    //Constructor
    public ControlPanelForm() {
    }

    public static ControlPanelForm getInstance() {
        if (unique == null) {
            unique = new ControlPanelForm();
        }
        return unique;
    }

    public void initialize() {
        
        dat.addObserver(this);
        //Identify user (Staff or Manager)
        if(Data.getCurrentUser() instanceof Manager){
            identifyUser = "Manager";
        }else{
            identifyUser = "Staff";
        }
        
        //Create Instance 
        if(identifyUser.equals("Manager")){
            comboBoxContents = new String[]{"Teacher", "Student", "Class", "Manager", "Staff",};
        }else if (identifyUser.equals("Staff")){
            comboBoxContents = new String[]{"Teacher", "Student", "Class", "Staff",};
        }
        userType = new JComboBox(comboBoxContents);
        
        //Settings
        userGuide.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, ActionEvent.ALT_MASK));
        
        //menu add menu item
        file.add(logout);
        file.add(exit);
        help.add(userGuide);
        //menu bar add menu
        menuBar.add(file);
        menuBar.add(edit);
        menuBar.add(help);
        //Add menu bar to JFrame
        add(menuBar, BorderLayout.NORTH);
        //Set layout for mother panel
        motherPanel.setLayout(null);
        //Make and add function panel to mother panel
        makeFunctionPanel();
        motherPanel.add(functionPanel);
        //Make content panel and add it to mother panel
        makeContentPanel();
        motherPanel.add(contentsPanel);
        //Add mother panel to the ManagerForm
        add(motherPanel, BorderLayout.CENTER);
        //Set settings for the ManagerForm
        setTitle("Quick Manage");
        setSize(999, 710);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        //Set listerners
        setListeners();
        //Set UI
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            SwingUtilities.updateComponentTreeUI(this);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Can't change look and feel", "Invalid PLAF",
                    JOptionPane.ERROR_MESSAGE);
        }

    }

    public void setListeners() {
        addButton.addActionListener(cpCon);
        userType.addActionListener(cpCon);
        deleteButton.addActionListener(deleteCon);
        activateButton.addActionListener(activateCon);
        timeTableButton.addActionListener(cpCon);
        copyClass.addActionListener(copyCon);
        userGuide.addActionListener(cpCon);
    }

    public void makeFunctionPanel() {
        //Set style for function panel
        functionPanel.setLayout(null);
        functionPanel.setBounds(0, 0, 993, 75);
        functionPanel.setBackground(new Color(213, 227, 255)); // Set color for top layout
        //Set location of buttons panel components
        addButton.setBounds(5, 5, 120, 30);
        deleteButton.setBounds(130, 5, 120, 30);
        activateButton.setBounds(255, 5, 120, 30);
        timeTableButton.setBounds(380, 5, 120, 30);
        copyClass.setBounds(510, 5, 120, 30);
        //Set location of search panel components
        userType.setBounds(335, 40, 120, 30);
        searchField.setBounds(465, 40, 355, 30);
        search.setBounds(828, 40, 90, 30);
        //Set string in combo box to be center
        DefaultListCellRenderer dlcr = new DefaultListCellRenderer();
        dlcr.setHorizontalAlignment(DefaultListCellRenderer.CENTER);
        userType.setRenderer(dlcr);
        //Search Hint
        PromptSupport.setPrompt("Search...", searchField);
        // CP Image
        URL url = ControlPanelForm.class.getResource("/Images/CP.png");
        try {
            myPicture = ImageIO.read(url);
        } catch (IOException ex) {
            Logger.getLogger(ControlPanelForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        picLabel = new JLabel(new ImageIcon(myPicture));
        picLabel.setBounds(900, 10, 100, 60);
        picLabel.setOpaque(false);

        //set font for all components of both panels
        addButton.setFont(font);
        deleteButton.setFont(font);
        activateButton.setFont(font);
        timeTableButton.setFont(font);
        userType.setFont(font);
        searchField.setFont(font);
        search.setFont(font);
        copyClass.setFont(font);
        //Add components to buttons panel
        functionPanel.add(addButton);
        functionPanel.add(deleteButton);
        functionPanel.add(activateButton);
        functionPanel.add(timeTableButton);
        functionPanel.add(copyClass);
        //Add components to search panel
        functionPanel.add(userType);
        functionPanel.add(searchField);
        functionPanel.add(search);
        functionPanel.add(picLabel);
    }

    public void makeContentPanel() {
        //set content panel style
        contentsPanel.setLayout(null);
        contentsPanel.setBounds(0, 70, 999, 590);
        contentsPanel.setBackground(Color.BLACK);
        
        //make left and right panels
        leftPanel = LeftPanel.getInstance();
        leftPanel.initialize();
        rightPanel = RightPanel.getInstance();
        rightPanel.initialize(deleteCon,activateCon, copyCon);
        
        //Add both panels to content panel
        contentsPanel.add(leftPanel);
        contentsPanel.add(rightPanel);
    }

    @Override
    public void update(Observable o, Object arg) {
        
    }
    
}
