package View;

import Controller.AllTimeTableController;
import Model.Data;
import TimetableUtilities.Timetable;
import java.awt.Font;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class AllTimeTable extends JFrame implements Observer {

    //Properties
    private static AllTimeTable unique;
    private Timetable timetable = new Timetable();
    private JLabel classNote = new JLabel("Class");
    private JLabel teacherNote = new JLabel("Teacher");
    private JLabel studentNote = new JLabel("Student");
    private JPanel overAll = new JPanel();
    private JButton close = new JButton("Close");
    private JList listClass = new JList();
    private JScrollPane scrollStudent = new JScrollPane();
    private JScrollPane scrollTeacher = new JScrollPane();
    private JScrollPane scrollClass = new JScrollPane();
    private String[] allClass = {"Piano", "Organ", "Violin", "Guitar", "Painting", "Singing", "Ballet", "Hiphop", "Photography"};
    private AllTimeTableController timCon = new AllTimeTableController();

    //Singleton
    public static AllTimeTable getInstance() {
        if (unique == null) {
            unique = new AllTimeTable();
        }
        return unique;
    }

    //Initialize
    public void initialize() {

        //settings
        this.getTimCon().addObserver(this);

        overAll.setLayout(null);
        timetable.settings();
        classNote.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 25));
        teacherNote.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 25));
        studentNote.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 25));

        scrollClass.setViewportView(listClass);
        scrollTeacher.setViewportView(this.getTimCon().getListTeacher());
        scrollStudent.setViewportView(this.getTimCon().getListStudent());

        listClass.setListData(allClass);
        this.getTimCon().getListTeacher().setEnabled(false);
        this.getTimCon().getListStudent().setEnabled(false);

        //Adding

        overAll.add(classNote);
        overAll.add(teacherNote);
        overAll.add(studentNote);
        overAll.add(scrollClass);
        overAll.add(scrollTeacher);
        overAll.add(scrollStudent);


        overAll.add(timetable);
        overAll.add(close);

        classNote.setBounds(870, 10, 100, 40);
        teacherNote.setBounds(855, 220, 100, 40);
        studentNote.setBounds(855, 400, 100, 40);
        close.setBounds(460, 620, 100, 40);
        timetable.setBounds(0, 0, 800, 600);
        scrollClass.setBounds(825, 50, 170, 170);
        listClass.setBounds(0, 0, 100, 100);

        scrollTeacher.setBounds(825, 270, 170, 130);
        this.getTimCon().getListTeacher().setBounds(0, 0, 100, 100);

        scrollStudent.setBounds(825, 440, 170, 220);
        this.getTimCon().getListStudent().setBounds(0, 0, 100, 100);

        add(overAll);

        //Set Listener
        close.addActionListener(timCon);
        listClass.addListSelectionListener(timCon);

        //JFrame's settings
        setTitle("TimeTable");
        setSize(1000, 705);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        AllTimeTable tim = AllTimeTable.getInstance();
        tim.initialize();
    }

    @Override
    public void update(Observable o, Object arg) {
    }

    public AllTimeTableController getTimCon() {
        return timCon;
    }

    public static void setUnique(AllTimeTable unique) {
        AllTimeTable.unique = unique;
    }

}
