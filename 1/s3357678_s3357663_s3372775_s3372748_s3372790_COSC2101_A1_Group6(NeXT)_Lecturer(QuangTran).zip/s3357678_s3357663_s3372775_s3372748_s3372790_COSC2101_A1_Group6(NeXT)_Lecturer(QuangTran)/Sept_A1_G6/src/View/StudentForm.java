package View;

import Controller.StudentFormController;
import Model.Classes;
import javax.swing.JButton;
import Model.Data;
import java.util.*;

public class StudentForm extends UserForm {

    private static StudentForm unique;
    private StudentFormController studentCon = new StudentFormController(this);
    private JButton enrollButton = new JButton("Enroll");
    private ArrayList<Classes> classes = new ArrayList<>();

    //Singleton
    public static StudentForm getInstance() {
        if (unique == null) {
            unique = new StudentForm();
        }
        return unique;
    }

    public void studentInitialize() {
        super.initialize();
        if (Data.studentList.isEmpty()) {
            this.idR.setText("S1");
        } else {
            String temp = Data.studentList.get(Data.studentList.size() - 1).getID();
            int num = Integer.parseInt(temp.substring(1));
            num++;
            this.idR.setText("S" + num);
        }

        //Create instance

        //Settings
        this.setUserType("Student");
        setTitle("Student Form");

        //Adding 
        userForm.add(enrollButton);

        enrollButton.setBounds(300, 420, 90, 25);

        //Set Listener
        add.addActionListener(studentCon);
        browse.addActionListener(studentCon);
        cancel.addActionListener(studentCon);
        enrollButton.addActionListener(studentCon);

        //JFrame's settings 
        setSize(440, 480);
        setTitle("Student Form");
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);

    }

    public static void setUnique(StudentForm unique) {
        StudentForm.unique = unique;
    }

    public ArrayList<Classes> getClasses() {
        return classes;
    }

    public void setClasses(ArrayList<Classes> classes) {
        this.classes = classes;
    }
}
