package View;

import Controller.EnrollmentFormController;
import TimetableUtilities.Timetable;
import java.awt.Font;
import java.util.Observable;
import java.util.Observer;
import javax.swing.*;

public class EnrollmentForm extends JFrame implements Observer {

    //Properties
    private static EnrollmentForm unique;
    private JLabel id = new JLabel("ID: ");
    private JLabel name = new JLabel("Name: ");
    private JLabel idR = new JLabel("IDR");
    private JLabel nameR = new JLabel("NameR");
    private Timetable timeTable = new Timetable();
    private JButton close = new JButton("Close");
    private JScrollPane scroll = new JScrollPane();
    private JScrollPane enrollScroll = new JScrollPane();
    private JList classesList = new JList();
    private JList enrolled = new JList();
    private JLabel classNote = new JLabel("Class");
    private JLabel enrollNote = new JLabel("Enrolled");
    private String[] allClass = {"Piano", "Organ", "Violin", "Guitar", "Painting", "Singing", "Ballet", "Hiphop", "Photography"};
    private String[] enrolledList ={""};
    private EnrollmentFormController enCon = new EnrollmentFormController();

    //Singeton
    public static EnrollmentForm getInstance() {
        if (unique == null) {
            unique = new EnrollmentForm();
        }

        return unique;
    }

    //Initialize
    public void initialize() {
        setLayout(null);
        enCon.addObserver(this);

        //Settings
        classesList.setListData(allClass);
        enrolled.setListData(enrolledList);
        
        timeTable.settings();
        classNote.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 25));
        enrollNote.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));

        //Adding
        scroll.setViewportView(classesList);
        enrollScroll.setViewportView(enrolled);
        
        add(id);
        add(name);
        add(idR);
        add(nameR);
        add(timeTable);
        add(close);
        add(scroll);
        add(enrollScroll);
        add(classNote);
        add(enrollNote);

        id.setBounds(40, 5, 20, 20);
        name.setBounds(20, 45, 50, 20);
        idR.setBounds(70, 5, 60, 20);
        nameR.setBounds(70, 45, 100, 20);
        timeTable.setBounds(200, 0, 800, 600);
        close.setBounds(450, 615, 100, 45);
        scroll.setBounds(20, 350, 150, 250);
        enrollScroll.setBounds(20, 130, 150, 150);
        classesList.setBounds(0, 0, 100, 100);
        classNote.setBounds(60, 300, 100, 40);
        enrollNote.setBounds(18, 70, 100, 40);

        //SEt listeners
        close.addActionListener(enCon);
        classesList.addListSelectionListener(enCon);

        //JFrame's settings 
        setTitle("Enrollment Form");
        setSize(1000, 705);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        EnrollmentForm enroll = EnrollmentForm.getInstance();
        enroll.initialize();

    }

    @Override
    public void update(Observable o, Object arg) {
    }

    public void setEnrolledList(String[] data){
        enrolledList = data;
        
    }
    
    public static void setUnique(EnrollmentForm unique) {
        EnrollmentForm.unique = unique;
    }

    public JLabel getIdR() {
        return idR;
    }

    public void setIdR(JLabel id) {
        this.idR = id;
    }

    public JLabel getStudentName() {
        return nameR;
    }

    public void setStudentName(JLabel name) {
        this.nameR = name;
    }

    public Timetable getTimeTable() {
        return timeTable;
    }

    public void setTimeTable(Timetable timeTable) {
        this.timeTable = timeTable;
    }

    public EnrollmentFormController getEnCon() {
        return enCon;
    }

    public void setEnCon(EnrollmentFormController enCon) {
        this.enCon = enCon;
    }
    
    
}
