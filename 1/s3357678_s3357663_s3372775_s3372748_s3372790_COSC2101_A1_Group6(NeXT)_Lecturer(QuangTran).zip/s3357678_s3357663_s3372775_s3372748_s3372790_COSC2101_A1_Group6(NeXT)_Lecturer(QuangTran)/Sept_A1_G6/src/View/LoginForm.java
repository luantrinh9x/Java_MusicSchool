package View;

import Controller.LoginFormController;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LoginForm extends JFrame {

    //Propeties
    private static LoginForm unique;
    private JPanel overAll;
    private JPanel mainPanel;
    private JMenuBar menubar;
    private JMenuItem menuitem;
    private JMenu menu;
    private JLabel quickmanage;
    private JLabel usrnameL;
    private JLabel passwordL;
    private JTextField usrnameF;
    private JLabel backgroundImg;
    private JPasswordField passwordF;
    private JButton login = new JButton("Log in");
    private JButton exit = new JButton("Exit");
    private LoginFormController loginController = new LoginFormController();
    //Singleton

    public static LoginForm getInstance() {
        if (unique == null) {
            unique = new LoginForm();
        }
        return unique;
    }

    //Initialize
    public void initialize() {
        //Create instance
        createInstance();

        //Settings
        createSettings();

        //Set Listener
        createListener();

        //Adding to JFrame and Components
        createAdding();

        //JFrame's settings 
        setTitle("Quick Manage - Login");
        setSize(450, 280);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Set look and feel
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            SwingUtilities.updateComponentTreeUI(this);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Can't change look and feel", "Invalid PLAF",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void createInstance() {
        menubar = new JMenuBar();
        menu = new JMenu("Manage");
        menuitem = new JMenuItem("      Close", KeyEvent.VK_F2);
        usrnameL = new JLabel("Username:");
        usrnameF = new JTextField(80);
        passwordL = new JLabel("Password:");
        passwordF = new JPasswordField(80);
        overAll = new JPanel();
        quickmanage = new JLabel("Quick Manage");
        mainPanel = new JPanel();
        backgroundImg = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0,
                        new Color(150, 189, 228), 450, 450,
                        new Color(150, 228, 228));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());

                super.paintComponent(g);
            }
        };
    }

    public void createSettings() {
        overAll.setLayout(new BorderLayout());
        mainPanel.setLayout(null);
        menu.setMnemonic(KeyEvent.VK_M);
        menuitem.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_F2, ActionEvent.SHIFT_MASK));
        usrnameF.setFont(new Font("Serif", Font.PLAIN, 16));
        passwordF.setFont(new Font("Serif", Font.PLAIN, 16));
        quickmanage.setFont(new Font("Comic sans ms", Font.PLAIN, 30));
    }

    public void createAdding() {
        add(overAll);

        menubar.add(menu);
        menu.add(menuitem);

        mainPanel.add(usrnameL);
        mainPanel.add(passwordL);
        mainPanel.add(usrnameF);
        mainPanel.add(passwordF);
        mainPanel.add(quickmanage);
        mainPanel.add(login);
        mainPanel.add(exit);
        mainPanel.add(backgroundImg);

        overAll.add(menubar, BorderLayout.NORTH);
        overAll.add(mainPanel, BorderLayout.CENTER);

        quickmanage.setBounds(140, 5, 200, 60);
        usrnameL.setBounds(40, 80, 100, 30);
        usrnameF.setBounds(140, 80, 260, 30);
        passwordL.setBounds(40, 140, 100, 30);

        passwordF.setBounds(140, 140, 260, 30);
        login.setBounds(320, 190, 80, 30);

        exit.setBounds(230, 190, 80, 30);

        backgroundImg.setBounds(0, 0, 484, 230);
    }

    public void createListener() {
        login.addMouseListener(loginController);
        menuitem.addActionListener(loginController);
        this.addKeyListener(loginController);
        usrnameF.addKeyListener(loginController);
        passwordF.addKeyListener(loginController);
        exit.addMouseListener(loginController);
    }

    public JTextField getUsrnameF() {
        return usrnameF;
    }

    public JPasswordField getPasswordF() {
        return passwordF;
    }

    public JButton getLogin() {
        return login;
    }
}
