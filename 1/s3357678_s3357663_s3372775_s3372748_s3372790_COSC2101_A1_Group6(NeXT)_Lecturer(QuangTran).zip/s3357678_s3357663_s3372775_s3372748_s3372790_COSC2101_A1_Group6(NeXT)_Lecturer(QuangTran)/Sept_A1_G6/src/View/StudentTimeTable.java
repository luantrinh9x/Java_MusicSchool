package View;

import java.awt.event.*;
import javax.swing.*;
import TimetableUtilities.*;

public class StudentTimeTable extends JFrame {
    //Properties

    private static StudentTimeTable unique;
    private Timetable timeTable = new Timetable();
    private JButton close = new JButton("Close");
    private JButton click = new JButton("Show");

    //Singeton
    public static StudentTimeTable getInstance() {
        if (unique == null) {
            unique = new StudentTimeTable();
        }
        return unique;
    }

    //Initialize
    public void initialize() {
        setLayout(null);
        timeTable.settings();
        //remove old timetables
//        timeTablePanel.removeAll();
        //JFrame's settings 

//        timeTablePanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        timeTable.setBounds(30, 15, 800, 600);
        click.setBounds(100, 620, 100, 45);
        click.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StudentTimeTable.getInstance().getTimeTable().getTimeModel().change();
            }
        });

        //Set Close button
        close.setBounds(400, 630, 80, 30);
        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(close);
        add(timeTable);
        add(click);
        //setLayout(new BorderLayout());
        setTitle("View Time Table Student");
        setSize(850, 700);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) throws InterruptedException {

//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(UserForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }

        StudentTimeTable studentTime = StudentTimeTable.getInstance();
        studentTime.initialize();
//        studentTime.getTimeTable().getTimeModel().resetChosenClass();
        studentTime.getTimeTable().getTimeController().onCreateClass("1",
                "Mon",
                "09:00",
                "10:30",
                "sample name",
                "1",
                "SAM123",
                "1",
                "");
//
//        studentTime.getTimeTable().getTimeModel().change();
    }

    public Timetable getTimeTable() {
        return timeTable;
    }

    public void setTimeTable(Timetable timeTable) {
        this.timeTable = timeTable;
    }

    public static void setUnique(StudentTimeTable unique) {
        StudentTimeTable.unique = unique;
    }
}
