package View;

import Controller.TeacherFormController;
import javax.swing.*;
import Model.Data;

public class TeacherForm extends UserForm {

    //Properties
    private static TeacherForm unique;
    private final int numberOfSkill = 9;
    private JCheckBox[] allSkill = new JCheckBox[numberOfSkill];
    private JButton assignButton;
    private TeacherFormController teacherCon = new TeacherFormController(this);

    //Singleton
    public static TeacherForm getInstance() {
        if (unique == null) {
            unique = new TeacherForm();
        }
        return unique;
    }

    //Initialize
    public void TeacherInitialize() {
        super.initialize();
        if (Data.teacherList.isEmpty()) {
            this.idR.setText("V1");
        } else {
            String temp = Data.teacherList.get(Data.teacherList.size() - 1).getID();
            int num = Integer.parseInt(temp.substring(1));
            num++;
            this.idR.setText("V" + num);
        }

        this.setUserType("Teacher");

        //piano, organ, violin, guitar, painting, singing, ballet, hiphop, photography;
        allSkill[0] = new JCheckBox("Piano");
        allSkill[1] = new JCheckBox("Organ");
        allSkill[2] = new JCheckBox("Violin");
        allSkill[3] = new JCheckBox("Guitar");
        allSkill[4] = new JCheckBox("Painting");
        allSkill[5] = new JCheckBox("Singing");
        allSkill[6] = new JCheckBox("Ballet");
        allSkill[7] = new JCheckBox("Hiphop");
        allSkill[8] = new JCheckBox("Photography");
        assignButton = new JButton("Assign");

        status.setBounds(10, 480, 50, 25);
        allSkill[0].setBounds(110, 380, 60, 25);
        allSkill[1].setBounds(190, 380, 60, 25);
        allSkill[2].setBounds(260, 380, 70, 25);
        allSkill[3].setBounds(110, 440, 60, 25);
        allSkill[4].setBounds(190, 440, 80, 25);
        allSkill[5].setBounds(110, 410, 70, 25);
        allSkill[6].setBounds(190, 410, 70, 25);
        allSkill[7].setBounds(260, 410, 80, 25);
        allSkill[8].setBounds(260, 440, 100, 25);
        skill.setBounds(10, 380, 50, 25);
        status.setBounds(10, 480, 50, 25);
        statusR.setBounds(110, 480, 100, 25);
        add.setBounds(90, 520, 80, 25);
        cancel.setBounds(270, 520, 80, 25);
        assignButton.setBounds(180, 520, 80, 25);

        for (int i = 0; i < allSkill.length; i++) {
            userForm.add(allSkill[i]);
        }

        userForm.add(skill);
        userForm.add(assignButton);

        //Set Listener
        add.addActionListener(teacherCon);
        browse.addActionListener(teacherCon);
        cancel.addActionListener(teacherCon);
        assignButton.addActionListener(teacherCon);

        //JFrame's settings 
        setTitle("Add Teacher Form");
        setSize(440, 590);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
    }

    public int getNumberOfSkill() {
        return numberOfSkill;
    }

    public JCheckBox[] getAllSkill() {
        return allSkill;
    }

    public static void setUnique(TeacherForm unique) {
        TeacherForm.unique = unique;
    }
}
