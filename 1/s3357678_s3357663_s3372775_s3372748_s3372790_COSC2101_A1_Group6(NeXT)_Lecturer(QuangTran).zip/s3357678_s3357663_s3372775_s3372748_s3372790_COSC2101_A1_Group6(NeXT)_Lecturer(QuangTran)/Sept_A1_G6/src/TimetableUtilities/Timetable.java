/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TimetableUtilities;

import Model.Data;
import Model.Student;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Observable;
import java.util.Observer;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author Thinh
 */
public class Timetable extends JPanel implements Observer {

    //Properties
    private final int ONTOP = 1;
    private final int ONBOTTOM = 2;
    private JLayeredPane layer = new JLayeredPane();
    private TimetableController timeController = new TimetableController(this);
    private TimetableModel timeModel = new TimetableModel();

    public Timetable() {
    }

    //settings method
    public void settings() {

        //settings
        timeModel.addObserver(this);
        int count = 0;
        int checktime = 0;
        int checkday = 0;
        int tableCellNumber = 0;
        Color color = new Color(176, 196, 222);

        setLayout(new GridLayout(23, 8));
        setSize(new Dimension(800, 600));

//        setBorder(BorderFactory.createLineBorder(Color.red));


        for (int i = 0; i < (23 * 8); i++) {
            String toadd = "";
            JLabel inside = new JLabel();
            JPanel wrapinside = new JPanel();


            //Add Weekday
            if (i >= 1 && i <= 7) {
                toadd = timeModel.getWeekday()[count];
                count++;
                color = new Color(176, 196, 222);
                inside.setText(toadd);

                //Add weektime
            } else if (i != 0 && i % 8 == 0) {
                checkday = 0;
                toadd = timeModel.getWeektime()[count];
                color = new Color(176, 196, 222);
                count++;
                if (i >= 16) {
                    checktime++;
                }
                inside.setText(toadd);

                //Put color to the rest of field
            } else if (i != 0) {
                color = new Color(240, 248, 255);
                toadd = timeModel.getWeekday()[checkday]
                        + timeModel.getWeektime()[checktime];
                checkday++;
            }
            if (i == 7) {
                count = 0;
            }
//            if( i)

            inside.setHorizontalAlignment(SwingConstants.CENTER);

            wrapinside.setBackground(color);
            wrapinside.setBorder(BorderFactory.createLineBorder(Color.gray));

//            wrapinside.addMouseMotionListener(timeController);
//            wrapinside.addMouseListener(timeController);


            while (toadd.length() != 16) {
                toadd = toadd + "+";
            }
            wrapinside.setName(toadd);

            wrapinside.add(inside);
            wrapinside.setBounds(0, 0, 100, 100);

            timeModel.getTableCell()[tableCellNumber] = wrapinside;
            tableCellNumber++;
            add(wrapinside);
//            System.out.println(toadd); 

        }

//        for(int i = 0; i < timeController.getTimeModel().getTableCell().length;i++){
//            System.out.println(timeController.getTimeModel().getTableCell()[i].getName());
//        }
        System.out.println("PRint out first time");
        layer.add(this, ONBOTTOM);

    }

    @Override
    public void update(Observable o, Object arg) {

        this.removeAll();
        this.validate();
        this.repaint();

        for (int i = 0; i < timeModel.getChosenClass().size(); i++) {
            layer.add(timeModel.getChosenClass().get(i), ONTOP);
            add(timeModel.getChosenClass().get(i));
            timeModel.getChosenClass().get(i).setBounds(timeModel.getChosenClass().get(i).getCorX(),
                    timeModel.getChosenClass().get(i).getCorY(), 100, 26 * timeModel.getChosenClass().get(i).getRatio());
        }

        for (int i = 0; i < timeModel.getTableCell().length; i++) {
            add(timeModel.getTableCell()[i]);
        }

    }

    public TimetableController getTimeController() {
        return timeController;
    }

    public TimetableModel getTimeModel() {
        return timeModel;
    }

    public void setPanelListener() {
        for (CoverPanel item : timeModel.getChosenClass()) {
            item.addMouseListener(timeController);
        }
    }
}
